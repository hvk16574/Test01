SELECT   organization_id, costed_flag, COUNT (1)
    FROM mtl_material_transactions
   WHERE costed_flag IN ('E', 'N')
GROUP BY organization_id, costed_flag;



SELECT hou.organization_id, mp.organization_code, hou.NAME organization_name
  FROM mtl_parameters mp, hr_organization_units hou
 WHERE mp.organization_id(+) = hou.organization_id
   AND hou.organization_id IN (SELECT DISTINCT organization_id
                                          FROM mtl_material_transactions
                                         WHERE costed_flag IN ('N'));

SELECT *
  FROM mtl_material_transactions
 WHERE costed_flag IN ('E') AND organization_id = 106