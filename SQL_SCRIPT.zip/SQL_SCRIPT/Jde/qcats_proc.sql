CREATE OR REPLACE PROCEDURE QCATS_JDE_Load IS
   CURSOR c1
   IS
        SELECT  DATE2JDE(FLT_DATE) FLT_DATE, FLT_NUM, ORGN||'-'||DEST ROUTE,ETD,AC_REG_NUM, REGION, FINAL_CONFIGF CONFIGF, FINAL_CONFIGC CONFIGC, 
        FINAL_CONFIGY CONFIGY,FINAL_CABIN_CREW CC, FINAL_DECK_CREW DC,  PRE_ORDERF D8F, PRE_ORDERC D8C, PRE_ORDERY D8Y,FINAL_ORDERF D4F, 
        FINAL_ORDERC D4C, FINAL_ORDERY D4Y, ABS(D90_UPLIFT_F) D90F,ABS(D90_UPLIFT_C) D90C, ABS(D90_UPLIFT_Y) D90Y,  ABS(D60_UPLIFT_F) D60F, 
        ABS(D60_UPLIFT_C) D60C, ABS(D60_UPLIFT_Y) D60Y, ABS(D45_UPLIFT_F) D45F, ABS(D45_UPLIFT_C) D45C, ABS(D45_UPLIFT_Y) D45Y,
        FLOOR ( ( ( ((FLT_DATE + SUBSTR(ETD,1,2)/24) + SUBSTR(ETD,3,2)/1440) - SYSDATE) * 24 * 60 * 60) /60)  HM
        FROM V_QCATS_FLIGHTLOAD 
        WHERE (SYSDATE - (FLT_DATE + SUBSTR (ETD, 1, 2) / 24) + SUBSTR (ETD, 3, 2) / 1440) / 8 < 0
            AND ( (FLT_DATE + SUBSTR (ETD, 1, 2) / 24) + SUBSTR (ETD, 3, 2) / 1440) < SYSDATE + 8 / 24
            AND ( (FLT_DATE + SUBSTR (ETD, 1, 2) / 24) + SUBSTR (ETD, 3, 2) / 1440) - 45 / 1440 >= SYSDATE
        ORDER BY (FLT_DATE + SUBSTR (ETD, 1, 2) / 24) + SUBSTR (ETD, 3, 2) / 1440;

   CURSOR c2 (v_flight_date NUMBER, v_flight_no VARCHAR2, v_route VARCHAR2)
   IS
      SELECT   QADBLDATE,LPAD (TRIM (SUBSTR (QADBLFLT, 3)), 4, '0') QADBLFLT, QADBLALPH,QAAFTCONFC, QAAFTCONJC, QAAFTCONYC,QA06HRFLG,
                    QAPL06HRFC, QAPL06HRJC, QAPL06HRYC, QAPL03HRFC, QAPL03HRJC, QAPL03HRYC, QAPL00HRFC, QAPL00HRJC, QAPL00HRYC
      FROM   F550060_V
      WHERE QADBLDATE = V_FLIGHT_DATE AND LPAD (TRIM (SUBSTR (QADBLFLT, 3)), 4, '0') = V_FLIGHT_NO AND TRIM (QADBLALPH) = V_ROUTE
      FOR UPDATE;

   c1rec   c1%ROWTYPE;
   c2rec   c2%ROWTYPE;
BEGIN
   FOR c1_rec IN c1
   LOOP
--      dbms_output.put_line( 'C1 :- '|| c1_rec.FLT_DATE||'-'||c1_rec. FLT_NUM||'-'||c1_rec.  ROUTE||'-'||c1_rec.ETD||'-'||c1_rec.AC_REG_NUM||'-'||c1_rec. REGION||'-'||c1_rec. CONFIGF||'-'||c1_rec. CONFIGC||'-'||c1_rec. CONFIGY||'-'||c1_rec.CC||'-'||c1_rec.  DC||'-'||c1_rec.  D8F||'-'||c1_rec. D8C||'-'||c1_rec. D8Y||'-'||c1_rec. D4F||'-'||c1_rec.          D4C||'-'||c1_rec.  D4Y||'-'||c1_rec. D90F||'-'||c1_rec. D90C||'-'||c1_rec. D90Y||'-'||c1_rec.  D60F||'-'||c1_rec. D60C||'-'||c1_rec.  D60Y||'-'||c1_rec.  D45F||'-'||c1_rec.  D45C||'-'||c1_rec.  D45Y||'-'||c1_rec. HM );
      FOR c2_rec IN c2 (c1_rec.FLT_DATE, c1_rec.FLT_NUM, c1_rec.ROUTE)
      LOOP
--         DBMS_OUTPUT.put_line ('Minutes to depart :' || c1_rec.HM || ' C2 : ' || c2_rec.QADBLDATE||'-'||c2_rec.QADBLFLT||'-'||c2_rec. QADBLALPH||'-'||c2_rec.QAAFTCONFC||'-'||c2_rec. QAAFTCONJC||'-'||c2_rec. QAAFTCONYC||'-'||c2_rec.QA06HRFLG||'-'||c2_rec.QAPL06HRFC||'-'||c2_rec. QAPL06HRJC||'-'||c2_rec. QAPL06HRYC||'-'||c2_rec. QAPL03HRFC||'-'||c2_rec.QAPL03HRJC||'-'||c2_rec. QAPL03HRYC||'-'||c2_rec. QAPL00HRFC||'-'||c2_rec. QAPL00HRJC||'-'||c2_rec. QAPL00HRYC);
           IF c1_rec.REGION = 'IG'  AND c1_rec.HM <= 45  THEN  --DBMS_OUTPUT.put_line('IG-45');
           UPDATE   f550060_v
               SET   QA00HRFLG = 1, 
               QAPL00HRFC = c1_rec.d4f + c1_rec.d90f + c1_rec.d60f + c1_rec.d45f,
               QAPL00HRJC = c1_rec.d4c + c1_rec.d90c + c1_rec.d60c + c1_rec.d45c,
               QAPL00HRYC = c1_rec.d4y + c1_rec.d90y + c1_rec.d60y + c1_rec.d45y
             WHERE   CURRENT OF c2;
           ELSIF c1_rec.HM <=60 THEN --DBMS_OUTPUT.put_line('60');
           UPDATE   f550060_v
               SET   QA00HRFLG = 1, 
               QAPL00HRFC = c1_rec.d4f + c1_rec.d90f + c1_rec.d60f ,
               QAPL00HRJC = c1_rec.d4c + c1_rec.d90c + c1_rec.d60c ,
               QAPL00HRYC = c1_rec.d4y + c1_rec.d90y + c1_rec.d60y 
             WHERE   CURRENT OF c2;           
           ELSIF c1_rec.HM <=90 THEN --DBMS_OUTPUT.put_line('90');
           UPDATE   f550060_v
               SET   QA00HRFLG = 1, 
               QAPL00HRFC = c1_rec.d4f + c1_rec.d90f  ,
               QAPL00HRJC = c1_rec.d4c + c1_rec.d90c  ,
               QAPL00HRYC = c1_rec.d4y + c1_rec.d90y  
             WHERE   CURRENT OF c2;           
           ELSIF c1_rec.HM <=240 THEN --DBMS_OUTPUT.put_line('240');
           UPDATE   f550060_v
               SET   QA03HRFLG = 1, 
               QAPL03HRFC = c1_rec.d4f ,
               QAPL03HRJC = c1_rec.d4c ,
               QAPL03HRYC = c1_rec.d4y   
             WHERE   CURRENT OF c2;           
           ELSIF c1_rec.HM <=480 THEN --DBMS_OUTPUT.put_line('480');
           UPDATE   f550060_v
               SET   QA06HRFLG = 1, 
               QAPL06HRFC = c1_rec.d8f ,
               QAPL06HRJC = c1_rec.d8c ,
               QAPL06HRYC = c1_rec.d8y   
             WHERE   CURRENT OF c2;           
           ELSE null; --DBMS_OUTPUT.put_line('ERROR');
           END IF;
      END LOOP;
   END LOOP;
END;
/