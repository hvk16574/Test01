DECLARE 
  P_UNIQ_NUM NUMBER;
  OUT_STR NUMBER;
BEGIN 
  P_UNIQ_NUM := 569161;
  OUT_STR := NULL;
  Proc_Single_Dty_Mig ( P_UNIQ_NUM, OUT_STR );
  COMMIT; 
END;


select * from IFLY_DTY_APP_DTL where  emp_cde = 491

select * from user_jobs