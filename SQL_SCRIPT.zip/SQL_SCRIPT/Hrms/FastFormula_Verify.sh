Notes start. 

Save formula file as pyformula.hdt (Any name but .hdt)

Another file with following text and save as pyffupload.hct (Any name but .hct)

update ff_formulas_f set formula_text = :formula where formula_name='QC_ANNUAL_LEAVE_ACCRUAL' and effective_start_date=to_date('01/01/1951','DD/MM/YYYY') 

LOCAL pyformula.hdt QR_ANNUAL_LEAVE_ACCRUAL 

Notest end.


$FF_TOP/bin/FFXMLC apps/appssitr@SIT 0 Y LOCAL pyffupload.hct 

Formula Compile
$FF_TOP/bin/FFXBCP apps/appssitr@SIT 0 Y %% QF_PTO_PAYROLL_BALANCE_CALCULATION

