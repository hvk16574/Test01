SELECT   DISTINCT employee_number, full_name, segment5 "Pigeon Hole No."
  FROM   per_all_people_f papf,
         per_all_assignments_f paaf,
         per_grades pg,
         PER_PERSON_ANALYSES ppa,
         PER_ANALYSIS_CRITERIA pac
 WHERE       papf.person_id = paaf.person_id
         AND organization_id = 574
         AND pg.grade_id = paaf.grade_id
         AND primary_flag = 'Y'
         AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                 AND  paaf.effective_end_date
         AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                 AND  papf.effective_end_date
         AND current_employee_flag = 'Y'
         AND PPA.PERSON_ID = papf.person_id
         AND PAC.ANALYSIS_CRITERIA_ID = PPA.ANALYSIS_CRITERIA_ID
         AND (ppa.ID_FLEX_NUM = 50227)