SELECT *                                                            --count(*)
  FROM (SELECT paat.absence_attendance_type_id absence_attendance_type_id,
               'A' approval_status_code, fcl.meaning absence_category,
               NULL ikey, NULL transaction_id, NULL datest, NULL dateend
          FROM per_absence_attendances paa,
               per_absence_attendance_types paat,
               per_abs_attendance_types_tl paattl,
               hr_lookups fcl
         WHERE paa.person_id = :person_id
           AND paa.business_group_id + 0 = 81
           AND paa.absence_attendance_type_id =
                                               paat.absence_attendance_type_id
           AND paat.absence_attendance_type_id =
                                             paattl.absence_attendance_type_id
           AND paattl.LANGUAGE = USERENV ('LANG')
           AND fcl.lookup_type(+) = 'ABSENCE_CATEGORY'
           AND paat.absence_category = fcl.lookup_code(+)
           AND (   (    hr_api.return_legislation_code (paat.business_group_id) =
                                                                          'GB'
                    AND NVL (paat.absence_category, '#') NOT IN
                                ('M', 'GB_PAT_ADO', 'GB_PAT_BIRTH', 'GB_ADO')
                   )
                OR (    hr_api.return_legislation_code (paat.business_group_id) <>
                                                                          'GB'
                    AND NVL (paat.absence_category, '#') NOT IN
                                     ('GB_PAT_ADO', 'GB_PAT_BIRTH', 'GB_ADO')
                   )
               )
           AND NOT EXISTS (
                  SELECT 'e'
                    FROM hr_api_transactions t
                   WHERE t.selected_person_id = paa.person_id
                     AND t.creator_person_id =
                                         NVL (:person_id, t.creator_person_id)
                     AND t.transaction_ref_table = 'PER_ABSENCE_ATTENDANCES'
                     AND t.transaction_ref_id = paa.absence_attendance_id
                     AND NOT (    hr_absutil_ss.getabsencetype
                                                            (t.transaction_id,
                                                             NULL
                                                            ) IS NULL
                              AND t.status = 'W'
                             )
                     AND t.status NOT IN ('D', 'E'))
        UNION ALL
        SELECT TO_NUMBER (hats.information5) absence_attendance_type_id,
               hr_absutil_ss.getapprovalstatuscode
                                    (hat.transaction_id,
                                     NULL
                                    ) approval_status_code,
               hr_absutil_ss.getabsencecategory
                                        (hat.transaction_id,
                                         NULL
                                        ) absence_category,
               hat.item_key, hat.transaction_id,
               TO_DATE (hats.information1, 'yyyy-mm-dd'),
               TO_DATE (hats.information2, 'yyyy-mm-dd')
          FROM hr_api_transactions hat, hr_api_transaction_steps hats
         WHERE hat.transaction_ref_table = 'PER_ABSENCE_ATTENDANCES'
           AND hat.transaction_group = 'ABSENCE_MGMT'
           AND hat.transaction_identifier = 'ABSENCES'
           AND hat.transaction_ref_id IS NOT NULL
           AND hat.selected_person_id = :person_id
           AND hat.creator_person_id = NVL (:person_id, hat.creator_person_id)
           AND hat.transaction_id = hats.transaction_id(+)
           AND hat.status NOT IN ('D', 'E')
           --AND hat.status IN ('Y', 'W')
           AND NOT (    hr_absutil_ss.getabsencetype (hat.transaction_id,
                                                      NULL) IS NULL
                    AND hat.status = 'W'
                   )) qrslt
 WHERE qrslt.approval_status_code IN ('Y', 'W', 'A')
   AND qrslt.absence_category = 'Vacation'
   AND qrslt.absence_attendance_type_id = 62
 --paat.ABSENCE_ATTENDANCE_TYPE_ID
 --and paat.absence_attendance_type_id =62
--and to_char(to_date(qrslt.date_start,'YYYY-MM-DD'),'DD-MON-RRRR') <> to_date(:p_lv_str_date,'DD-MON-RRRR')
--and to_char(to_date(qrslt.date_end,'YYYY-MM-DD'),'DD-MON-RRRR') <> to_date(:p_lv_end_date,'DD-MON-RRRR')
 --and  paat.absence_category ='V';

--select person_id from per_all_people_f where employee_number ='25272'