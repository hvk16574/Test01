SELECT papf.employee_number, paa.date_start leave_start_date,
       paa.date_end leave_end_date, paa.absence_days,
       paa.date_notification notified_date
  FROM per_all_people_f papf,
       per_all_assignments_f paaf,
       per_absence_attendances paa,
       per_absence_attendance_types paat
 WHERE papf.person_id = paaf.person_id
   AND papf.current_employee_flag = 'Y'
   AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                           AND papf.effective_end_date
   AND paaf.primary_flag = 'Y'
   AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                           AND paaf.effective_end_date
   AND paaf.person_id = paa.person_id
   AND paa.absence_attendance_type_id = paat.absence_attendance_type_id
   AND paa.date_start BETWEEN :sd AND :ed
   AND paat.absence_category IN ('V')
   AND paaf.payroll_id = 61
   AND hr_general.decode_grade (paaf.grade_id) LIKE 'CC%'
   AND hr_general.decode_organization (paaf.organization_id) LIKE
                                                           'Cabin Crew Flying'