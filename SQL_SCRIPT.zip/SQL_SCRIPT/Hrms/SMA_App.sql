SELECT transaction_id,item_key, PROCESS_NAME
  FROM hr_api_transactions
 WHERE selected_person_id IN
          (SELECT person_id FROM per_all_people_f
            WHERE TRUNC (SYSDATE) BETWEEN effective_start_date AND effective_end_date
                  AND applicant_number = LPAD (TRUNC (:app_num), 5, '0'))

       AND status = 'Y';

SELECT item_key, PROCESS_NAME
  FROM hr_api_transactions
 WHERE selected_person_id IN
          (SELECT person_id FROM per_all_people_f
            WHERE TRUNC (SYSDATE) BETWEEN effective_start_date AND effective_end_date
                  AND employee_number = LPAD (TRUNC (:app_num), 5, '0')) AND item_key IS NOT NULL

       AND status = 'Y';

--For Approved/ Rejected Transactions

SELECT * FROM QAG_HR_SMA_APPREJ_MOVEREP_V                                                                --where applicant_number='23795'
 WHERE employee_number = '32292';

--wf_notifications
-- For pending transactions

SELECT * FROM QAG_HR_SMA_MOVEMENT_REPORT_V;

--where applicant_number=' ''

--where employee_number=' ''