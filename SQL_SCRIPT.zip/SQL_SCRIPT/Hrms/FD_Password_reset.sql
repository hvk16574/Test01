DECLARE
   CURSOR c1
   IS
      SELECT DISTINCT employee_number, date_of_birth
                 FROM per_all_people_f papf,
                      per_all_assignments_f paaf,
                      per_grades pg,
                      fnd_user u
                WHERE papf.person_id = paaf.person_id
                  AND pg.grade_id = paaf.grade_id
                  AND primary_flag = 'Y'
                  AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                          AND paaf.effective_end_date
                  AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                          AND papf.effective_end_date
                  AND current_employee_flag = 'Y'
                  AND u.user_name = papf.employee_number
                  and employee_number in ('03330',
'01616',
'09184',
'02820',
'26143',
'03193',
'06949',
'01767');

   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER         := NULL;
   x_start_date                   DATE           := SYSDATE;
   x_end_date                     DATE           := NULL;
   x_last_logon_date              DATE           := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE           := NULL;
   x_password_accesses_left       NUMBER         := NULL;
   x_password_lifespan_accesses   NUMBER         := NULL;
   x_password_lifespan_days       NUMBER         := NULL;
   x_employee_id                  NUMBER         := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER         := NULL;
   x_supplier_id                  NUMBER         := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name := c1_rec.employee_number;
      x_unencrypted_password := TO_CHAR (c1_rec.date_of_birth, 'DDMMYYYY');
      apps.fnd_user_pkg.updateuser (x_user_name, 0, x_unencrypted_password);
   END LOOP;
END;