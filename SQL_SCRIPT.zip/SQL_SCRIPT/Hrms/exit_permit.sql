SELECT papf.employee_number "Employee Number",
       NVL (pac_visa.segment8,
            papf.title || papf.first_name || papf.last_name
           ) "Full Name",
       pac_passport.segment1 "Passport No",
       TO_DATE (pac_passport.segment6,
                'yyyy/mm/dd hh24:mi:ss'
               ) "Passport Expiry",
       pac_visa.segment1 rpno,
       TO_DATE (pac_visa.segment3,
                'yyyy/mm/dd hh24:mi:ss'
               ) "Residence Permit Expiry",
       QUERY.destination "Destination",
       TO_DATE (QUERY.cexit, 'yyyy/mm/dd hh24:mi:ss') "Exit Date",
       TO_CHAR (SYSDATE, 'DD') sys_day, TO_CHAR (SYSDATE, 'MON') sys_mon,
       TO_CHAR (SYSDATE, 'YY') sys_year,
       SUBSTR (TO_CHAR (TO_DATE (QUERY.cexit, 'yyyy/mm/dd hh24:mi:ss')),
               1,
               2
              ) "Exit day",
       SUBSTR (TO_CHAR (TO_DATE (QUERY.cexit, 'yyyy/mm/dd hh24:mi:ss')),
               4,
               3
              ) "Exit month",
       SUBSTR (TO_CHAR (TO_DATE (QUERY.cexit, 'yyyy/mm/dd hh24:mi:ss')),
               8,
               2
              ) "Exit year",
       REPLACE (org.NAME, CHR (32), CHR (10)) "department name",
       org.NAME "department name1"
                                  --,query.cvalue "Value From"
       , papf.person_id, pac_passport.segment10 "Primary Flag"
  FROM per_all_people_f papf,
       per_person_analyses ppa,
       per_person_analyses ppa1,
       per_analysis_criteria pac_passport,
       per_analysis_criteria pac_visa,
       per_all_assignments_f paaf                                       -- sat
                                 ,
       hr_all_organization_units org
-- Generic Table creation statement for Exit Permit(s).
,
       (SELECT ppa.person_id, pac.segment2 destination, pac.segment1 cexit
          FROM per_person_analyses ppa, per_analysis_criteria pac
         WHERE ppa.analysis_criteria_id = pac.analysis_criteria_id
           AND ppa.id_flex_num =
                            (SELECT id_flex_num
                               FROM fnd_id_flex_structures
                              WHERE id_flex_structure_code = 'QA_EXIT_PERMIT')
           AND ppa.date_to IS NULL
--     and  ppa.date_from=(select max(date_from) from per_person_analyses where person_id=ppa.person_id and id_flex_num=ppa.id_flex_num)
        UNION
        SELECT paa.person_id, paa.attribute17 "Destination",
               paa.attribute16 "Exit Date"
          FROM per_absence_attendances paa
         WHERE paa.attribute17 IS NOT NULL AND paa.attribute16 IS NOT NULL
        UNION
        SELECT paa.person_id, paa.attribute1 "Destination 1",
               paa.attribute18 "Alternate Departure Date 1"
          FROM per_absence_attendances paa
         WHERE paa.attribute1 IS NOT NULL AND paa.attribute18 IS NOT NULL
        UNION
        SELECT paa.person_id, paa.attribute2 "Destination 2",
               paa.attribute19 "Alternate Departure Date 2"
          FROM per_absence_attendances paa
         WHERE paa.attribute2 IS NOT NULL AND paa.attribute19 IS NOT NULL
        UNION
        SELECT ppa_sdt.person_id, pac_sdt.segment3,
               TO_CHAR (TO_DATE (pac_sdt.segment5, 'yyyy/mm/dd hh24:mi:ss')
                        - 1,
                        'YYYY-MON-DD'
                       )
          --pac_sdt.segment5-1
        FROM   per_person_analyses ppa_sdt, per_analysis_criteria pac_sdt
         WHERE ppa_sdt.analysis_criteria_id = pac_sdt.analysis_criteria_id
           AND ppa_sdt.id_flex_num =
                     (SELECT id_flex_num
                        FROM fnd_id_flex_structures
                       WHERE id_flex_structure_code = 'QA_SINGLE_DUTY_TRAVEL')
           AND pac_sdt.segment5 IS NOT NULL
           AND ppa_sdt.date_to IS NULL
        UNION
        SELECT DISTINCT papf.person_id, pac.segment3 destination,
                        pac.segment5 cexit
                   FROM per_analysis_criteria pac,
                        per_person_analyses ppa,
                        per_all_people_f papf
                  WHERE pac.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
                    AND pac.segment12 IS NOT NULL
                    AND ppa.person_id = papf.person_id
                    AND papf.employee_number IS NOT NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment19),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment19 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment20),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment20 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment21),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment21 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment22),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment22 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment23),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment23 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment24),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment24 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment25),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment25 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment26),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment26 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment27),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment27 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment28),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment28 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment29),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment29 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL
        UNION
        SELECT DISTINCT qag_sshr_staff_name.get_staff_number (pac1.segment30),
                        pac1.segment3, pac1.segment5
                   FROM per_analysis_criteria pac1, per_person_analyses ppa
                  WHERE pac1.segment30 IS NOT NULL
                    AND pac1.id_flex_num =
                           (SELECT id_flex_num
                              FROM fnd_id_flex_structures
                             WHERE id_flex_structure_code =
                                                       'QAG_GROUP_DUTY_TRAVEL')
                    AND pac1.analysis_criteria_id = ppa.analysis_criteria_id
                    AND pac1.id_flex_num = ppa.id_flex_num
                    AND ppa.date_to IS NULL) QUERY
 WHERE papf.person_id = QUERY.person_id
   AND papf.person_id = paaf.person_id                                  -- sat
   AND papf.person_id = ppa.person_id
   AND papf.person_id = ppa1.person_id
   AND pac_passport.analysis_criteria_id = ppa.analysis_criteria_id
   AND pac_passport.id_flex_num =
                      (SELECT id_flex_num
                         FROM fnd_id_flex_structures
                        WHERE id_flex_structure_code = 'QAG_Passport_Details')
   AND pac_visa.analysis_criteria_id = ppa1.analysis_criteria_id
   AND pac_visa.id_flex_num =
              (SELECT id_flex_num
                 FROM fnd_id_flex_structures
                WHERE id_flex_structure_code = 'QAG_Residence_Permit_Details')
   AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                           AND paaf.effective_end_date
   AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                           AND papf.effective_end_date
   AND ppa.date_from =
          (SELECT MAX (date_from)
             FROM per_person_analyses
            WHERE person_id = ppa.person_id
              AND id_flex_num =
                      (SELECT id_flex_num
                         FROM fnd_id_flex_structures
                        WHERE id_flex_structure_code = 'QAG_Passport_Details'))
   AND paaf.organization_id = org.organization_id
   AND papf.employee_number = :emp_num
   AND UPPER (pac_visa.segment4) = 'COMPANY'
   AND paaf.supervisor_id IS NOT NULL
   AND NVL (UPPER (hr_general.decode_position_current_name (paaf.position_id)),
            '1'
           ) NOT LIKE '%CASH%'