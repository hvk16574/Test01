SELECT a.date_start, a.date_end, ABSENCE_DAYS, b.name
  FROM PER_ABSENCE_ATTENDANCES a, PER_ABSENCE_ATTENDANCE_TYPES b
 WHERE person_id IN (SELECT person_id FROM per_all_people_f WHERE employee_number = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0'))
       AND a.ABSENCE_ATTENDANCE_TYPE_ID = b.ABSENCE_ATTENDANCE_TYPE_ID;
       
       
SELECT to_char(a.date_start,'YYYY'), b.name, count(ABSENCE_DAYS),sum(ABSENCE_DAYS)
  FROM PER_ABSENCE_ATTENDANCES a, PER_ABSENCE_ATTENDANCE_TYPES b
 WHERE person_id IN (SELECT person_id FROM per_all_people_f WHERE employee_number = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0'))
       AND a.ABSENCE_ATTENDANCE_TYPE_ID = b.ABSENCE_ATTENDANCE_TYPE_ID
       group by to_char(a.date_start,'YYYY'), b.name
       order by 1,2;
       
  SELECT TO_CHAR (a.date_start, 'YYYY'), b.name, sum(absence_days) Total, COUNT (ABSENCE_DAYS) Occurence, LISTAGG (ABSENCE_DAYS, ',') WITHIN GROUP (ORDER BY a.date_end) Leaves
    FROM PER_ABSENCE_ATTENDANCES a, PER_ABSENCE_ATTENDANCE_TYPES b
   WHERE person_id IN (SELECT person_id FROM per_all_people_f WHERE employee_number = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')), 5, '0'))
         AND a.ABSENCE_ATTENDANCE_TYPE_ID = b.ABSENCE_ATTENDANCE_TYPE_ID
GROUP BY TO_CHAR (a.date_start, 'YYYY'), b.name;

