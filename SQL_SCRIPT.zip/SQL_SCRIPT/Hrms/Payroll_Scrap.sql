Declare
l_err_msg VARCHAR2(350);
l_valid BOOLEAN;
l_total_cnt NUMBER;
l_succ_cnt NUMBER;
l_err_cnt NUMBER;
xp_ovn NUMBER;
x_inv_next_sal_date_warning BOOLEAN;
x_proposed_salary_warning BOOLEAN;
x_approved_warning BOOLEAN;
x_payroll_warning BOOLEAN;
cursor cur_sal_prosl is
select ppp.PAY_PROPOSAL_ID , PPP.OBJECT_VERSION_NUMBER,ppp.CHANGE_DATE,ppp.APPROVED,
  paaf.ASSIGNMENT_ID,  papf.EMPLOYEE_NUMBER,papf.FULL_NAME,ppp.PROPOSED_SALARY,ppp.PROPOSED_SALARY_N 
from per_pay_proposals ppp
,per_all_people_f papf
, per_all_assignments_f paaf
where papf.person_id=paaf.person_id 
and trunc(sysdate) between papf.EFFECTIVE_START_DATE and papf.EFFECTIVE_END_DATE
and trunc(sysdate) between paaf.EFFECTIVE_START_DATE and paaf.EFFECTIVE_END_DATE
and papf.CURRENT_EMPLOYEE_FLAG ='Y'
and paaf.PRIMARY_FLAG ='Y'
and paaf.ASSIGNMENT_ID =ppp.ASSIGNMENT_ID;
--and papf.EMPLOYEE_NUMBER ='00881'--in ('21873','06878','23339');
Begin
 l_total_cnt :=0;
 l_succ_cnt :=0;
 l_err_cnt :=0;
 l_valid := false;
For c1 in cur_sal_prosl
LOOP
  l_total_cnt := l_total_cnt+1;
  xp_ovn := c1.OBJECT_VERSION_NUMBER;
BEGIN
update per_pay_proposals set APPROVED ='N'
where assignment_id = c1.ASSIGNMENT_ID;
select OBJECT_VERSION_NUMBER 
into xp_ovn
from 
per_pay_proposals
where PAY_PROPOSAL_ID = c1.PAY_PROPOSAL_ID;
HR_MAINTAIN_PROPOSAL_API.update_salary_proposal
(
  p_pay_proposal_id              =>c1.PAY_PROPOSAL_ID,
  p_object_version_number        => xp_ovn,
  p_validate                     =>l_valid,
  p_proposed_salary_n            => 9999999,
  p_approved                     =>'Y',
  p_inv_next_sal_date_warning    => x_inv_next_sal_date_warning,
  p_proposed_salary_warning     =>x_proposed_salary_warning,
  p_approved_warning             =>x_approved_warning,
  p_payroll_warning              =>x_payroll_warning);

l_succ_cnt :=l_succ_cnt+1;

EXCEPTION
WHEN OTHERS THEN
l_err_cnt := l_err_cnt+1;
  --l_err_msg := substr(sqlerrm,1,300);
 --dbms_output.put_line(l_err_msg);
END;
END LOOP;
dbms_output.put_line('l_total_cnt='||l_total_cnt);
dbms_output.put_line('l_succ_cnt='||l_succ_cnt);
dbms_output.put_line('l_err_cnt='||l_err_cnt);
END;

------ Second Script


DECLARE
   CURSOR cur_grade_rate_update
   IS
      SELECT DISTINCT pg.NAME, psp.spinal_point_id, pgr.SEQUENCE
                    , pgr.grade_rule_id, pgr.object_version_number, VALUE
                 FROM apps.per_all_assignments_f ass
                    , apps.per_spinal_point_placements_f spp
                    , apps.per_spinal_point_steps_f psps
                    , apps.per_spinal_points psp
                    , apps.per_grade_spines_f pgs
                    , apps.pay_grade_rules_f pgr
                    , per_grades pg
                WHERE ass.primary_flag = 'Y'
                  AND TRUNC( SYSDATE ) BETWEEN ass.effective_start_date
                                           AND ass.effective_end_date
                  AND TRUNC( SYSDATE ) BETWEEN pgr.effective_start_date
                                           AND pgr.effective_end_date
                  AND TRUNC( SYSDATE ) BETWEEN spp.effective_start_date
                                           AND spp.effective_end_date
                  AND TRUNC( SYSDATE ) BETWEEN psps.effective_start_date
                                           AND psps.effective_end_date
                  AND spp.step_id = psps.step_id
                  AND psp.spinal_point_id = psps.spinal_point_id
                  AND psp.parent_spine_id = spp.parent_spine_id
                  AND psps.grade_spine_id = pgs.grade_spine_id
                  AND psp.spinal_point_id = pgr.grade_or_spinal_point_id
                  AND spp.assignment_id = ass.assignment_id
                  AND pgr.rate_type = 'SP'
                  AND pg.grade_id(+) = pgs.grade_id
                  AND ass.pay_basis_id = 90
--                  AND psp.spinal_point_id = 61
             ORDER BY 1;

   l_effective_start_date    DATE;
   l_effective_end_date      DATE;
   l_object_version_number   NUMBER;
BEGIN
   BEGIN
      FOR rec_grade_rate_update IN cur_grade_rate_update
      LOOP
         l_object_version_number := 0;
         l_object_version_number :=
                                  rec_grade_rate_update.object_version_number;

         BEGIN
            hr_rate_values_api.update_assignment_rate_value
                        ( p_validate                   => FALSE
                        , p_grade_rule_id              => rec_grade_rate_update.grade_rule_id
                        , p_effective_date             => TO_DATE
                                                              ( '21-JAN-2010'
                                                              , 'DD-MON-YYYY' )
                        , p_datetrack_mode             => 'CORRECTION'
                        , p_currency_code              => 'QAR'
                        , p_value                      => '99999'
                        , p_object_version_number      => l_object_version_number
                        , p_effective_start_date       => l_effective_start_date
                        , p_effective_end_date         => l_effective_end_date
                        );
            COMMIT;
         EXCEPTION
            WHEN OTHERS
            THEN
               DBMS_OUTPUT.put_line( SQLERRM );
         END;
      END LOOP;
   END;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line( SQLERRM );
END;

