DECLARE
   l_blob    BLOB;
   l_bfile   BFILE;
BEGIN
-- First create a Empty binary large object and get a reference
   INSERT INTO per_images_hvk
        VALUES (1, 192832, 'PER_PEOPLE_F', EMPTY_BLOB ())
     RETURNING image
          INTO l_blob;

-- Get the pointer to a file in directory
-- First Parameter is Database Directory and Second is Image file name
   l_bfile := BFILENAME ('HAMID', '23339.jpg');
-- Open File
   DBMS_LOB.fileopen (l_bfile);
-- Load Image from file
   DBMS_LOB.loadfromfile (l_blob, l_bfile, DBMS_LOB.getlength (l_bfile));
   DBMS_LOB.fileclose (l_bfile);
END;