SELECT   papf.employee_number sup_num, papf.full_name sup_name,
         papf1.employee_number sub_num, papf1.full_name sub_name, paaf.person_id
    FROM per_all_people_f papf,
         per_all_people_f papf1,
         per_all_assignments_f paaf
   WHERE paaf.supervisor_id = papf.person_id
     AND papf1.person_id = paaf.person_id
     AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                             AND papf.effective_end_date
     AND papf.current_employee_flag = 'Y'
     AND paaf.primary_flag = 'Y'
     AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                             AND paaf.effective_end_date
     AND papf.employee_number = :p_sup_emp_no
     AND papf1.current_employee_flag = 'Y'
     AND TRUNC (SYSDATE) BETWEEN papf1.effective_start_date
                             AND papf1.effective_end_date
ORDER BY papf.employee_number