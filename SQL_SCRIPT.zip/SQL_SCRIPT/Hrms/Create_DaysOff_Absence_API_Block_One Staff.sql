select employee_number,person_id from per_all_people_f where employee_number= :emp_num

declare
l_dur_dys_less_warning boolean;   
l_dur_hrs_less_warning boolean;
l_exceeds_pto_entit_warning boolean;
l_exceeds_run_total_warning boolean;
l_abs_overlap_warning  boolean;
l_abs_day_after_warning  boolean;
l_dur_overwritten_warning  boolean;
l_absence_attendance_id number;
l_object_version_number number;
l_occurrence number;
l_absence_hours number;
l_absence_days number;
l_err_cnt number;
l_read_cnt number;
l_succ_cnt number;
l_ds date;
l_de date;
begin
l_absence_hours:=null;
l_ds:=TO_DATE('28-MAY-2010');
l_de:=TO_DATE('31-MAY-2010');
l_absence_days:=(l_de-l_ds)+1;
--l_absence_days:=4;
l_succ_cnt :=0;
l_err_cnt :=0;
l_read_cnt :=0;
l_read_cnt :=l_read_cnt+1;
begin
HR_PERSON_ABSENCE_API.create_person_absence
                          (p_validate                      =>false
                          ,p_effective_date                =>TRUNC(SYSDATE) 
                          ,p_person_id                     =>41776    
                          ,p_business_group_id             =>81
                          ,p_absence_attendance_type_id    =>3362 
                          ,p_abs_attendance_reason_id      =>2321
--                          ,p_comments                      =>l_comments 
                          ,p_date_notification             =>TRUNC(SYSDATE)
--                          ,p_date_projected_start          =>l_date_projected_start
--                          ,p_date_projected_end            =>l_date_projected_end 
                          ,p_date_start                    =>l_ds
                          ,p_date_end                      =>l_de
                          ,p_absence_days                  =>l_absence_days  
                       ,p_absence_hours                 =>l_absence_hours
  --                        ,p_authorising_person_id         =>l_authorising_person_id 
    --                      ,p_attribute_category            =>l_attribute_category                           
      --                    ,p_replacement_person_id         =>l_replacement_person_id
  --                        ,p_attribute1                    =>l_attribute1 
--                          ,p_attribute2                    =>l_attribute2
                          ,p_attribute16                   => to_char(to_date('27-MAY-2010'),'YYYY/MM/DD HH24:MI:SS')   
                --        ,p_attribute17                   =>'DUBAI'
                  --   ,p_attribute9                   =>'N' 
                         /* ,p_attribute19                   =>l_attribute19 
                          ,p_attribute20                   =>l_attribute20 
                          ,p_absence_attendance_id        =>l_absence_attendance_id
                          ,p_object_version_number         =>l_object_version_number 
                          ,p_occurrence                    =>l_occurrence*/
                          ,p_absence_attendance_id         => l_absence_attendance_id
                          ,p_object_version_number         => l_object_version_number
                            ,p_occurrence                  => l_occurrence
                          ,p_dur_dys_less_warning          =>l_dur_dys_less_warning   
                          ,p_dur_hrs_less_warning           =>l_dur_hrs_less_warning 
                          ,p_exceeds_pto_entit_warning      =>l_exceeds_pto_entit_warning
                          ,p_exceeds_run_total_warning    =>l_exceeds_run_total_warning 
                          ,p_abs_overlap_warning          =>l_abs_overlap_warning  
                          ,p_abs_day_after_warning         =>l_abs_day_after_warning  
                          ,p_dur_overwritten_warning       =>l_dur_overwritten_warning
                          );
dbms_output.PUT_LINE('Success');
exception when others then
dbms_output.PUT_LINE(sqlerrm);
end;                          
end;