SELECT *
  FROM hr_api_transactions
 WHERE creator_person_id IN (SELECT person_id
                               FROM per_all_people_f
                              WHERE employee_number = '&emp_num')
and process_name = 'HR_LOA_JSP_PRC';

IF YOU WANT TO SEE IF WORFLOW IS PICKING UP PROPER HIERARCHY

SELECT  paf.person_id
    FROM    per_all_assignments_f paf
    START   WITH paf.person_id = (select distinct person_id from per_all_people_f where employee_number ='21531')
      AND     paf.primary_flag = 'Y'
      AND     trunc(sysdate)
      BETWEEN paf.effective_start_date
      AND     paf.effective_end_date
    CONNECT BY PRIOR paf.supervisor_id = paf.person_id
      AND     paf.primary_flag = 'Y'
      AND     trunc(sysdate)
      BETWEEN paf.effective_start_date
      AND     paf.effective_end_date
	  and rownum <=3


select distinct person_id,employee_number,full_name from per_all_people_f
where person_id in (3022,2983,124718)
and employee_number is not null -- put the above values returm from above query.

====================

check to see weather this employee is there in this table, if there than he can print the exit permit OR if he run regeneration program this staff number gets deleted from her. 

select * from QR_EPS_TEMP where employee_number ='08320'

To check the item key to aprove the request
================================================
select item_key,process_name from hr_api_transactions
where creator_person_id = (select person_id from per_all_people_f
where employee_number = '23899');


==========================
DELETE hr_api_transaction_values
WHERE transaction_step_id IN
(
SELECT transaction_step_id
FROM hr_api_transaction_steps
WHERE transaction_id
IN
(SELECT transaction_id FROM
hr_api_transactions
WHERE creator_person_id
IN
(
SELECT DISTINCT person_id FROM per_all_people_f
WHERE employee_number ='07646'
)
AND process_name ='HR_LOA_JSP_PRC' -- 'QR_PP_HR_SIT_JSP_PRC', 'QA_EP_HR_SIT_JSP_PRC', 'QR_PV_HR_SIT_JSP_PRC' , 'QA_SDT_HR_SIT_JSP_PRC'
)
)

DELETE hr_api_transaction_steps
WHERE  transaction_id
IN
(SELECT transaction_id FROM
hr_api_transactions
WHERE creator_person_id
IN
(
SELECT DISTINCT person_id FROM per_all_people_f
WHERE employee_number ='08813'
)
AND process_name ='HR_LOA_JSP_PRC' -- 'QR_PP_HR_SIT_JSP_PRC', 'QA_EP_HR_SIT_JSP_PRC', 'QR_PV_HR_SIT_JSP_PRC' , 'QA_SDT_HR_SIT_JSP_PRC'
)


DELETE hr_api_transactions
WHERE creator_person_id
IN
(
SELECT DISTINCT person_id FROM per_all_people_f
WHERE employee_number ='08813'
)
AND process_name ='HR_LOA_JSP_PRC' -- Leave process 


select * from hr_api_transactions
WHERE creator_person_id
IN
(
SELECT DISTINCT person_id FROM per_all_people_f
WHERE employee_number ='07646'
)
AND process_name ='HR_LOA_JSP_PRC' -- Leave process
and item_key =49408 
