SELECT -- COUNT (wf.text_value)
       tx.item_key, txval.date_value, txval.NAME, txval.number_value, wf.NAME,
       wf.text_value
  FROM wf_item_attribute_values wf,
       hr_api_transaction_steps tx,
       hr_api_transactions hrapi,
       hr_api_transaction_values txval
--       per_absence_attendance_types paat
WHERE  tx.item_key = wf.item_key
   AND hrapi.item_key = wf.item_key
   AND hrapi.transaction_id = tx.transaction_id
   AND tx.transaction_step_id = txval.transaction_step_id
   AND txval.NAME IN
               ('P_DATE_START', 'P_DATE_END', 'P_ABSENCE_ATTENDANCE_TYPE_ID')
--   AND txval.number_value = paat.absence_attendance_type_id
--   AND txval.number_value = p_abs_attnd_id
--   AND paat.absence_category = 'V'
   AND (   hrapi.selected_person_id = (SELECT DISTINCT person_id
                                                  FROM per_all_people_f
                                                 WHERE employee_number =
                                                                      :emp_num)
        OR hrapi.creator_person_id = (SELECT DISTINCT person_id
                                                 FROM per_all_people_f
                                                WHERE employee_number =
                                                                      :emp_num)
       )
   AND process_name = 'HR_LOA_JSP_PRC'
   AND wf.item_type = 'HRSSA'
   AND wf.NAME = 'TRAN_SUBMIT'
   AND wf.text_value = 'Y';

SELECT *
  FROM qr_eps_temp
 WHERE employee_number = '22427';

DELETE      hr_api_transaction_values
      WHERE transaction_step_id IN (
               SELECT transaction_step_id
                 FROM hr_api_transaction_steps
                WHERE item_key IN (
                         SELECT item_key
                           FROM hr_api_transactions
                          WHERE creator_person_id = 129491
                            AND process_name = 'HR_LOA_JSP_PRC'));

DELETE      hr_api_transaction_steps
      WHERE item_key IN (
               SELECT item_key
                 FROM hr_api_transactions
                WHERE creator_person_id = 129491
                  AND process_name = 'HR_LOA_JSP_PRC');

DELETE      hr_api_transactions
      WHERE creator_person_id = 129491 AND process_name = 'HR_LOA_JSP_PRC'