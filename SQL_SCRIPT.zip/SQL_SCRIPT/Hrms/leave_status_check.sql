  SELECT  date_start, date_end, to_date(ATTRIBUTE16,'yyyy/mm/dd hh24:mi:ss') exit_date, ATTRIBUTE17 destination, ATTRIBUTE20 reason
    FROM   PER_ABSENCE_ATTENDANCES
   WHERE   person_id =(SELECT   DISTINCT person_id FROM   per_all_people_f
                WHERE   employee_number = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')),5,'0'))
ORDER BY   date_start DESC;

select user_name,description, start_date, end_date from fnd_user where user_name in (
SELECT   distinct employee_number  FROM   per_all_people_f WHERE   person_id = '&person_id');


select * from hr_api_transactions where item_key = 1120636


wf_notifications

select * from qag_sshr_leave_history_tab
