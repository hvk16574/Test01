DECLARE
   l_blob    BLOB;
   l_bfile   BFILE;
   l_imgno   NUMBER;
   CURSOR c1
   IS
      SELECT   DISTINCT EMPLOYEE_NUMBER, PERSON_ID
        FROM   emp_photo
       WHERE   person_id NOT IN (SELECT   parent_id FROM per_images)
               AND employee_number NOT IN (SELECT   * FROM a);
BEGIN
   FOR c1_rec IN c1
   LOOP
      SELECT   per_images_s.NEXTVAL INTO l_imgno FROM DUAL;
      -- First create a Empty binary large object and get a reference
      INSERT INTO per_images VALUES   (l_imgno, c1_rec.person_id, 'PER_PEOPLE_F', EMPTY_BLOB ()) RETURNING image INTO   l_blob;
      -- Get the pointer to a file in directory
      -- First Parameter is Database Directory and Second is Image file name
      l_bfile := BFILENAME ('PHOTO_DIR', c1_rec.employee_number || '.jpg');
      -- Open File
      DBMS_LOB.fileopen (l_bfile);
      -- Load Image from file
      DBMS_LOB.loadfromfile (l_blob, l_bfile, DBMS_LOB.getlength (l_bfile));
      DBMS_LOB.fileclose (l_bfile);
      DBMS_OUTPUT.put_line (l_imgno || ' - ' || c1_rec.employee_number);
      UPDATE qr_aqd.en_web_users_local SET photoupload = 'Y' WHERE employee_no = c1_rec.employee_number;
   END LOOP;
END;


      --      l_imgno := l_imgno + 1;

SELECT   employee_no  FROM   qr_aqd.en_web_users_local WHERE   photoupload = 'N';
      
CREATE TABLE a
AS
   SELECT   *
     FROM   emp_photo
    WHERE   ROWNUM < 1;

SELECT   employee_number
  FROM   emp_photo
 WHERE   employee_number NOT IN (SELECT   * FROM a);

CREATE TABLE emp_photo
(
   employee_number   VARCHAR2 (30),
   person_id         NUMBER (10)
)
TABLESPACE qair;

UPDATE   emp_photo ep
   SET   ep.person_id =
            (SELECT   DISTINCT person_id
               FROM   per_all_people_f papf
              WHERE   papf.employee_number = ep.employee_number);

SELECT   *
  FROM   emp_photo
 WHERE   person_id IN (SELECT   parent_id FROM per_images);

SELECT   'copy ' || employee_number || '.jpg e:' FROM emp_photo;

SELECT   MAX (image_id) FROM per_images;

SELECT   per_images_s.NEXTVAL FROM DUAL;

INSERT INTO emp_photo
   SELECT   DISTINCT employee_number, person_id, NULL
     FROM   per_all_people_f
    WHERE   TRUNC (SYSDATE) BETWEEN effective_start_date
                                AND  effective_end_date
            AND current_employee_flag = 'Y'
            AND person_id NOT IN (SELECT   parent_id FROM per_images)
            AND employee_number NOT IN (SELECT   * FROM a);

SELECT   DISTINCT employee_number                   --, full_name, a.person_id
  FROM   per_all_people_f a, per_all_assignments_f paaf
 WHERE   a.person_id = paaf.person_id AND primary_flag = 'Y'
         AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                 AND  paaf.effective_end_date
         AND TRUNC (SYSDATE) BETWEEN a.effective_start_date
                                 AND  a.effective_end_date
         AND current_employee_flag = 'Y'
         AND a.person_id NOT IN (SELECT   parent_id FROM per_images);
