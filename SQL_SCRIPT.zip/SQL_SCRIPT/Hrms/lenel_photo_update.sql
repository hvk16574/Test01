DECLARE
   l_blob   BLOB;

   CURSOR cu
   IS
        --Update
        SELECT   *
          FROM   lenel_mmobjs
         WHERE   person_id IN (  SELECT   parent_id FROM per_images)
      ORDER BY   ssno;

BEGIN
   FOR c1_rec IN cu
   LOOP
      UPDATE   per_images
         SET   image = c1_rec.image
       WHERE   parent_id = c1_rec.person_id;

      DBMS_OUTPUT.put_line (c1_rec.ssno || ' - Update');
   END LOOP;

   UPDATE   per_images_job
      SET   LAST_UPDATE_DATE = SYSDATE;
END;


/*   FOR c1_rec IN ci
   LOOP
         l_blob  :=  c1_rec.image;
      INSERT INTO per_images_hk
        VALUES   (per_images_hk_s,
                  c1_rec.person_id,
                  c1_rec.table_name,
                  c1_rec.image) ;

      DBMS_OUTPUT.put_line (c1_rec.ssno || ' - Insert');
   END LOOP;
*/


/*
lenel_mmobjs - Query
SELECT   ssno,
         papf.person_id,
         'PER_PEOPLE_F' TABLE_NAME,
         lm.lnl_blob image
  FROM   mmobjs lm, emp e, per_all_people_f papf
 WHERE       lm.empid = e.id
         AND papf.employee_number = e.ssno
         AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date
         AND papf.current_employee_flag = 'Y'
         AND TYPE = 0
         AND OBJECT = 1
         AND TRUNC (lm.LASTCHANGED) >= (SELECT   TRUNC (last_update_date) FROM per_images_job)     
         
         
INSERT INTO per_images
   SELECT   per_images_s.NEXTVAL,
            person_id,
            table_name,
            image
     FROM   lenel_mmobjs
    WHERE   person_id NOT IN (SELECT   parent_id FROM per_images);
*/    