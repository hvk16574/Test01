DECLARE
   CURSOR c1
   IS
      SELECT   formula_name, formula_text
        FROM   FF_FORMULAS_F
       WHERE   FORMULA_NAME LIKE 'Q%';

   c1rec   c1%ROWTYPE;
   fn      UTL_FILE.file_type;
BEGIN
   OPEN c1;

   LOOP
      FETCH c1 INTO   c1rec;

      fn :=
         UTL_FILE.fopen ('/app/applptmp',
                         'HamidVKhan_' || c1rec.formula_name || '.txt',
                         'W');
      UTL_FILE.put (fn, c1rec.formula_text);
      UTL_FILE.FCLOSE_all;
      DBMS_OUTPUT.put_line('-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* Start Formula :'
                           || c1rec.formula_name
                           || ' -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*');
      DBMS_OUTPUT.put_line (c1rec.formula_text);
      DBMS_OUTPUT.put_line('-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-* End Formula :'
                           || c1rec.formula_name
                           || ' -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*');
      EXIT WHEN c1%NOTFOUND;
   END LOOP;

   CLOSE c1;
END;