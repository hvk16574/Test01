SELECT * 
  FROM TABLE (GV$ (CURSOR (SELECT i.instance_number inst_id, s.sid, p.spid, s.osuser, s.program, s.machine, s.username, 'alter system kill session '''||s.sid||','||s.serial#||''' immediate;'
                             FROM v$process p, v$session s, v$instance i
                            WHERE p.addr = s.paddr AND p.spid = trunc(:spid))));

SELECT k.*,'alter system kill session '''||sid||','||serial#||',@'||inst_id||''' immediate;' kill
  FROM TABLE (GV$ (CURSOR (SELECT i.instance_number inst_id, s.sid, s.serial#, s.osuser, s.program, s.machine, s.username,s.service_name
                             FROM v$access p, v$session s, v$instance i
                            WHERE p.sid = s.sid AND p.object = upper(:object_name)))) k;                            
                            
SELECT s.inst_id, s.sid,p.spid,s.osuser,s.program,s.machine,s.username
FROM   gv$process p,gv$session s
WHERE  p.addr = s.paddr and p.spid = :spid

and s.sid=3997  ; 

SELECT a.inst_id,a.sid, b.spid, a.username, a.osuser, a.machine
  FROM gv$session a, gv$process b
 WHERE a.paddr = b.addr(+)
 and spid = 21661
 
SELECT  distinct
'alter system kill session '''||sid||','||serial||',@'||inst_id||''';'
  FROM TABLE (GV$ (CURSOR (SELECT i.instance_number inst_id, s.sid, s.serial# serial, s.osuser, s.program, s.machine, s.username
                             FROM v$access p, v$session s, v$instance i
                            WHERE object = 'XXQR_EINV_LOG' AND s.sid = p.sid)));
 
SELECT  distinct
'alter system kill session '''||sid||','||serial||',@'||inst_id||''';'
  FROM TABLE (GV$ (CURSOR (SELECT i.instance_number inst_id, s.sid, s.serial# serial, s.osuser, s.program, s.machine, s.username
                             FROM v$session s, v$instance i
                            WHERE username = '&username' )));
                            
select 'alter system kill session '''||sid||','||serial#||''' immediate;' kill from v$session where username = '&username';

SELECT  *
--'alter system kill session '''||sid||','||serial||',@'||inst_id||''';'
  FROM TABLE (GV$ (CURSOR (SELECT i.instance_number inst_id, s.sid, s.serial# serial, s.osuser, s.program, s.machine, s.username
                             FROM v$access p, v$session s, v$instance i
                            WHERE object = upper(:object_name) AND s.sid = p.sid)));
                            
Select /*+RULE */  * from v$access where OBJECT=upper(:object_name);

select * from gdba_dml_locks where name = upper(:object_name);

FND_CONC_REQ_SUMMARY_V 

select * from FND_CONCURRENT_REQUESTS where 
--REQUEST_ID = '9548936'
PRIORITY_REQUEST_ID = 9548935 

select * from gv$session where program like '%PYUGE%'

select OUTFILE_NODE_NAME, LOGFILE_NODE_NAME  from FND_CONCURRENT_REQUESTS 
where REQUEST_ID in (9537307,9537306, 9537305, 9537304, 9537303, 9537302)



select * from gv$session where program like '%rwrun%'  
SELECT instance_name
  FROM TABLE (GV$ (CURSOR (SELECT instance_name FROM v$instance)));

SELECT *  FROM TABLE (GV$ (CURSOR (SELECT i.instance_number inst_id, name, a.blocked FROM v$active_services a, v$instance i)));  

-----------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT 'alter system kill session ''' || sid || ',' || serial# || ',@' || inst_id || ''' immediate;'
  FROM gv$session
 WHERE REGEXP_LIKE (program, '^(CRM|FFTM|FNDFD|FNDIM|ICM|INVMGR|PODAMGR|RCVOL|STANDARD)');

select 'alter system kill session '''||sid||','||serial#||',@'||inst_id||''' immediate;' from gv$session where regexp_like (username,'^(QRNOC)')

SELECT 'alter system kill session ''' || sid || ',' || serial# || ',@' || inst_id || ''' immediate;'
FROM TABLE ( GV$ (CURSOR (SELECT i.instance_number inst_id, sid, serial# FROM v$session, v$instance i
                         WHERE REGEXP_LIKE (program, '^(CRM|FFTM|FNDFD|FNDIM|ICM|INVMGR|PODAMGR|RCVOL|STANDARD)'))));
-----------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------                         