select segment1,creation_date,approved_date from po_requisition_headers_all
where trunc(creation_date) >= to_date('24/05/2009','dd/mm/yyyy')
and trunc(approved_date)  >= to_date('24/05/2009','dd/mm/yyyy')
and org_id = 81


select segment1,creation_date,approved_date from po_headers_all
where trunc(creation_date) >= to_date('24/05/2009','dd/mm/yyyy')
and trunc(approved_date)  >= to_date('24/05/2009','dd/mm/yyyy')
and org_id = 81



  SELECT   rvhv.CREATION_DATE,
           rvhv.CREATED_BY,
           RECEIPT_NUM,
           RECEIPT_DATE, ( SELECT   mp.organization_code
    FROM mtl_parameters mp, hr_organization_units hou
   WHERE mp.organization_id(+) = hou.organization_id and mp.organization_id =rsl_find.to_organization_id ) org_code
    FROM   RCV_VRC_HDS_V rvhv, rcv_shipment_lines rsl_find
   WHERE   rsl_find.shipment_header_id = rvhv.shipment_header_id 
                                               AND receipt_date >=
                 TO_DATE ('24-MAY-2009 00:00:00', 'DD-MON-YYYY HH24:MI:SS')
           AND-1 = -1
ORDER BY   5, receipt_num 


select * from tab where tname like 'MTL%ORG%'

SELECT   hou.organization_id, mp.organization_code,
         hou.NAME organization_name
    FROM mtl_parameters mp, hr_organization_units hou
   WHERE mp.organization_id(+) = hou.organization_id
ORDER BY mp.organization_id
