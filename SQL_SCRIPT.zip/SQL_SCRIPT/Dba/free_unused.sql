select j.*, trunc((est_mbytes - mbytes) / mbytes * 100) est_size_incr_pct, est_mbytes-mbytes est_size_incr_mbytes
  from (select g.*,
               trunc(table_space_estimate(g.tablespace_name,
                                         g.avg_row_len,
                                         g.num_rows,
                                         g.pct_free)/1024/1024) est_mbytes
          from (select s.owner,
                       s.segment_name,
                       s.partition_name,
                       s.tablespace_name,
                       decode(segment_type, 'TABLE PARTITION', p.AVG_ROW_LEN, t.AVG_ROW_LEN) avg_row_len,
                       decode(segment_type, 'TABLE PARTITION', p.NUM_ROWS, t.NUM_ROWS) num_rows,
                       decode(segment_type, 'TABLE PARTITION', p.pct_free, t.pct_free) pct_free,
                       decode(segment_type, 'TABLE PARTITION', p.last_analyzed, t.last_analyzed) last_analyzed,
                       s.mbytes
                  from (select *
                          from (select tablespace_name,
                                       owner,
                                       segment_name,
                                       trunc(bytes/1024/1024) mbytes,
                                       segment_type,
                                       a.partition_name
                                  from dba_segments a
                                 where segment_type in ('TABLE', 'TABLE PARTITION')
                                   and owner!='SYS'
                                 order by bytes desc)
                         where rownum <= 500) s,
                       dba_tables t,
                       dba_tab_partitions p
                 where t.owner(+) = s.owner
                   and t.table_name(+) = s.segment_name
                   and p.table_owner(+) = s.owner
                   and p.table_name(+) = s.segment_name
                   and p.partition_name(+) = s.partition_name) g
         order by mbytes desc) j order by est_mbytes-mbytes;