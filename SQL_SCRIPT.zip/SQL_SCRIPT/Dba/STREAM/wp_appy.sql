rem The following SQL statements can be cut and pasted into SQL*Plus or scripts for
rem for monitoring Streams.  
rem
rem See the MAA white paper "Oracle Streams Performance Performance Tuning Best Practice: Oracle 10g Release 10.2" which will reference this script.
rem
rem The following are for monitoring Streams
rem Apply.
rem
rem Run these SQL statements as the Streams administrator on the database instance running the Streams apply process.
rem


rem The following SQL shows streams pool statistics.  The query
rem only shows rows from v$streams_pool_advice where the size
rem factor is 1 or greater.  This limits the output to only
rem the estimated spill count at the current size and size
rem factors that would reduce estimated spill counts.

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       streams_pool_size_for_estimate,
       streams_pool_size_factor,estd_spill_count
from gv$streams_pool_advice
where streams_pool_size_factor >= 1;


rem The following SQL statements can be cut and pasted into scripts for
rem for monitoring Streams.  The following are for monitoring Streams
rem Apply.

rem Propagation Receiver stats

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       src_queue_schema, 
       src_queue_name,
       dst_queue_schema,dst_queue_name,
       high_water_mark,
       ACKNOWLEDGEMENT,
       total_msgs
from gv$propagation_receiver;

rem Apply reader status

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       apply_name,
       state,
       total_messages_dequeued,
       total_messages_spilled,
       sga_used
from gv$streams_apply_reader;

rem Apply Coordinator stats

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       apply_name,
       state,
       total_applied,
       total_wait_deps,
       total_wait_commits,
       total_assigned,
       total_received,
       total_ignored,
       total_rollbacks,
       total_errors
from gv$streams_apply_coordinator;

rem Apply Server stats (there can be more than one apply server).

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       apply_name,
       server_id,
       state,
       total_assigned,
       total_messages_applied
from gv$streams_apply_server
order by apply_name,server_id;

rem Transactions that apply is currently processing.  The transactions 
rem returned by this query on the target database can be compared to
rem to the those returned on the source database.  

select to_char(sysdate,'DD-MON-YY hh24:mi:ss') current_time,
       inst_id,
       streams_name,
       streams_type,
       XIDUSN || '.' ||
       XIDSLT || '.' ||
       XIDSQN,
       CUMULATIVE_MESSAGE_COUNT,
       TOTAL_MESSAGE_COUNT,
       to_char(FIRST_MESSAGE_TIME,'DD-MON-YY hh24:mi:ss') FIRST_MESSAGE_TIME,
                         FIRST_MESSAGE_NUMBER,
       to_char(LAST_MESSAGE_TIME,'DD-MON-YY hh24:mi:ss') LAST_MESSAGE_TIME,
                         LAST_MESSAGE_NUMBER
from gv$streams_transaction;

rem TXN_APPLY_LAG_TIME:
rem The following query provides the progress of apply for any transactions
rem that apply is processing.  It provides the lag time for how far behind
rem the apply process might be.

column oldest_transaction_id format a11
column Lag format a9

select applied_message_number,
       to_char(applied_message_create_time,'mm/dd/yy hh24:mi:ss') "Create Time",
       to_char(apply_time,'mm/dd/yy hh24:mi:ss') "Applied Time",
       to_char(extract(hour from (apply_time - applied_message_create_time)
          DAY TO SECOND), 'FM09') || ':' ||
       to_char(extract(minute from (apply_time - applied_message_create_time)
          DAY TO SECOND), 'FM09') || ':' ||
       to_char(extract(second from (apply_time - applied_message_create_time)
          DAY TO SECOND), 'FM09')  "Lag",
       extract(hour from (apply_time - applied_message_create_time)
          DAY TO SECOND) * 3600 +
       extract(minute from (apply_time - applied_message_create_time)
          DAY TO SECOND) * 60 +
       extract(second from (apply_time - applied_message_create_time)
          DAY TO SECOND) "Lag (Seconds)",
          oldest_transaction_id
from dba_apply_progress;

rem APPLY_WAIT_COMMIT:
rem This PL/SQL script computes the current percent wait commit
rem of the apply process.  
rem 


set serveroutput on
declare

     cursor c1 is
          select apply_name,
                 state,
                 total_wait_commits,
                 total_assigned
          from gv$streams_apply_coordinator;

begin

     dbms_output.put_line( to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') );

     FOR ac in c1 loop

          dbms_output.put('Apply: ' || ac.apply_name || '  ' ||
                          'Percent wait for commits: ');

          if ac.total_assigned > 0
          then
               dbms_output.put_line((ac.total_wait_commits / ac.total_assigned)*100);
          else
               dbms_output.put_line(0);
          end if;

     end loop;
end;
/



rem APPLY_PCT_IDLE
rem
rem The following query shows the percent idle of each apply server.
rem Each line of output provides information about each apply server.
rem Use this query to help determine if the apply servers have low
rem idle and to determine of the PARALLISM apply parameter needs to be 
rem increased.

SELECT COMPONENT_NAME,
      COMPONENT_TYPE,
      SUB_COMPONENT_TYPE,
      SERVER_ID,
      SESSION_ID,
      SESSION_SERIAL#,
      ROUND((1.0 - sum(EVENT_COUNT)/max(total_count)) * 1000)/10.0 as 
     PERCENT_IDLE
FROM (
      SELECT C.COMPONENT_NAME,
             C.COMPONENT_TYPE,
             C.SUB_COMPONENT_TYPE,
             C.SERVER_ID,
             C.SESSION_ID,
             C.SESSION_SERIAL#,
             ASH.EVENT,
             nvl(ASH.EVENT_COUNT, 0) as EVENT_COUNT,
             60 AS TOTAL_COUNT
      FROM ( -- APPLY SERVER
             SELECT apply_name     AS COMPONENT_NAME,
                    'APPLY'        AS COMPONENT_TYPE,
                    'APPLY SERVER' AS SUB_COMPONENT_TYPE,
                    server_id      AS SERVER_ID,
                    sid            AS SESSION_ID,
                    serial#        AS SESSION_SERIAL#
             FROM gv$streams_apply_server ) C,
           ( SELECT SESSION_ID,
                    SESSION_SERIAL#,
                    NVL(EVENT, 'CPU + Wait for CPU') AS EVENT,
                    COUNT(sample_time)               AS EVENT_COUNT
             FROM gv$active_session_history
             WHERE (sysdate - 1/24/60)  < sample_time AND sample_time 
<= sysdate
             GROUP BY session_id, session_serial#, event ) ASH
      WHERE C.SESSION_ID = ASH.SESSION_ID (+) AND
            C.SESSION_SERIAL# = ASH.SESSION_SERIAL# (+)
    )
GROUP BY COMPONENT_NAME, COMPONENT_TYPE, SUB_COMPONENT_TYPE, SERVER_ID,
SESSION_ID, SESSION_SERIAL#;

