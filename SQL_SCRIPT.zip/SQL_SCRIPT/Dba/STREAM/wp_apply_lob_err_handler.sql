rem This is a workaround for getting the apply process to assemble lobs 
rem by using a dummy error handler registered with the apply process.
rem Run this script as the streams asminstrator on the database running the Streams apply process.

set echo on
set serveroutput on

rem Create the dummy error hanlder. 

CREATE or REPLACE TYPE emsg_array IS TABLE of  VARCHAR2(100);
/


create or replace procedure apply_lob_err_dml_handler(
                             lcr_anydata IN Sys.Anydata,
                             error_stack_depth IN Number,
                             error_numbers IN Dbms_Utility.Number_Array,
                             error_messages IN emsg_array)
    authid current_user is
    lcr   sys.lcr$_row_record;
    dummy pls_integer;
begin
     dummy := lcr_anydata.getObject(lcr);
     lcr.execute(true);
end;
/


rem Now, register the above handler with the apply process for each table 
rem containing LOBs and for each operatoin.

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test1.content',
    object_type         => 'TABLE',
    operation_name      => 'UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test1.content',
    object_type         => 'TABLE',
    operation_name      => 'DELETE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test1.content',
    object_type         => 'TABLE',
    operation_name      => 'LOB_UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test2.content',
    object_type         => 'TABLE',
    operation_name      => 'UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test2.content',
    object_type         => 'TABLE',
    operation_name      => 'DELETE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test2.content',
    object_type         => 'TABLE',
    operation_name      => 'LOB_UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test3.content',
    object_type         => 'TABLE',
    operation_name      => 'UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test3.content',
    object_type         => 'TABLE',
    operation_name      => 'DELETE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test3.content',
    object_type         => 'TABLE',
    operation_name      => 'LOB_UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test4.content',
    object_type         => 'TABLE',
    operation_name      => 'UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test4.content',
    object_type         => 'TABLE',
    operation_name      => 'DELETE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test4.content',
    object_type         => 'TABLE',
    operation_name      => 'LOB_UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test5.content',
    object_type         => 'TABLE',
    operation_name      => 'UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test5.content',
    object_type         => 'TABLE',
    operation_name      => 'DELETE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test5.content',
    object_type         => 'TABLE',
    operation_name      => 'LOB_UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test6.content',
    object_type         => 'TABLE',
    operation_name      => 'UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test6.content',
    object_type         => 'TABLE',
    operation_name      => 'DELETE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/

BEGIN
  DBMS_APPLY_ADM.SET_DML_HANDLER(
    object_name         => 'test6.content',
    object_type         => 'TABLE',
    operation_name      => 'LOB_UPDATE',
    error_handler       => true,
    user_procedure      => 'streamsadmin.apply_lob_err_dml_handler',
    apply_database_link => NULL,
    apply_name          => NULL,
    assemble_lobs       => true);
END;
/


