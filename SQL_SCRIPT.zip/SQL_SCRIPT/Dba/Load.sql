SELECT   inst_id, stat_name s1, VALUE v1
    FROM gv$osstat
   WHERE stat_name = 'LOAD'
ORDER BY inst_id;

SELECT *
  FROM v$instance;

SELECT   instance_name, host_name, instance_role, startup_time, VALUE LOAD
    FROM gv$instance gvi, gv$osstat gvo
   WHERE gvo.inst_id = gvi.inst_id AND stat_name = 'LOAD'
ORDER BY gvi.inst_id;