  SELECT                                                                                                                  /*+   */
        CONCURRENT_PROGRAM_ID,
           PROGRAM_APPLICATION_ID,
           PRINTER,
           PROGRAM_SHORT_NAME,
           ARGUMENT_TEXT,
           PRINT_STYLE,
           USER_PRINT_STYLE,
           SAVE_OUTPUT_FLAG,
           ROW_ID,
           ACTUAL_COMPLETION_DATE,
           COMPLETION_TEXT,
           PARENT_REQUEST_ID,
           REQUEST_TYPE,
           FCP_PRINTER,
           FCP_PRINT_STYLE,
           FCP_REQUIRED_STYLE,
           LAST_UPDATE_DATE,
           LAST_UPDATED_BY,
           REQUESTED_BY,
           HAS_SUB_REQUEST,
           IS_SUB_REQUEST,
           UPDATE_PROTECTED,
           QUEUE_METHOD_CODE,
           RESPONSIBILITY_APPLICATION_ID,
           RESPONSIBILITY_ID,
           CONTROLLING_MANAGER,
           LAST_UPDATE_LOGIN,
           PRIORITY_REQUEST_ID,
           ENABLED,
           REQUESTED_START_DATE,
           PHASE_CODE,
           HOLD_FLAG,
           STATUS_CODE,
           REQUEST_ID,
           PROGRAM,
           REQUESTOR,
           PRIORITY
    FROM   FND_CONC_REQ_SUMMARY_V
    where program_short_name = 'CMCTCM';
    
update mtl_material_transactions
set costed_flag = 'N',
request_id = NULL,
transaction_group_id = NULL,
error_code = NULL,
error_explanation = NULL
where costed_flag in ('N','E');

select organization_id,costed_flag,count(1)
from mtl_material_transactions
where costed_flag in ('E','N')
group by organization_id,costed_flag
/
    

select organization_id,costed_flag,ERROR_EXPLANATION
from mtl_material_transactions
where costed_flag = 'E'
--group by organization_id,costed_flag
/
    