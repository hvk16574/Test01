CREATE OR REPLACE PROCEDURE max_shooter_proc (
   MESSAGE IN SYS.scheduler$_event_info)
AS
BEGIN
   -- if this is not a JOB_OVER_MAX_DUR message, error out
   IF MESSAGE.event_type != 'JOB_OVER_MAX_DUR'
   THEN
      RAISE PROGRAM_ERROR;
   END IF;

   -- stop the job
   DBMS_SCHEDULER.stop_job ('"' || MESSAGE.object_owner || '"."' || MESSAGE.object_name || '"',TRUE);
END;
/

BEGIN
   DBMS_SCHEDULER.create_program (program_name          => 'MAX_SHOOTER_PROG',
                                  program_action        => 'max_shooter_proc',
                                  program_type          => 'STORED_PROCEDURE',
                                  number_of_arguments   => 1,
                                  enabled               => FALSE);

   DBMS_SCHEDULER.define_metadata_argument ('MAX_SHOOTER_PROG', 'event_message', 1);
   DBMS_SCHEDULER.enable ('MAX_SHOOTER_PROG');
END;
/


exec dbms_scheduler.add_event_queue_subscriber('jdeagent')

BEGIN
   DBMS_SCHEDULER.create_job (
      'MAX_SHOOTER_JOB',
      program_name      => 'MAX_SHOOTER_PROG',
      event_condition   => 'tab.user_data.event_type = ''JOB_OVER_MAX_DUR''',
      queue_spec        => 'sys.scheduler$_event_queue,jdeagent',
      enabled           => TRUE);
END;
/

BEGIN
   DBMS_SCHEDULER.set_attribute ('QCATS_JDE_LOAD_UPLOAD', 'max_run_duration', INTERVAL '60' SECOND);
END;
/

DELETE sys.scheduler$_job_run_details
 WHERE log_id IN (SELECT log_id FROM sys.scheduler$_event_log WHERE NAME = 'EXCHANGE_CHK_JOB' AND STATUS = 'SUCCEEDED');

DELETE sys.scheduler$_event_log WHERE NAME = 'EXCHANGE_CHK_JOB' AND STATUS = 'SUCCEEDED';