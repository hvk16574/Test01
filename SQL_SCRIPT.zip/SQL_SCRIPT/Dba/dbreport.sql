SELECT * FROM qrdba_db_size;

  SELECT TO_CHAR (cr_date, 'MON-YYYY') Month,
         CEIL (AVG (SUBSTR (databasesize, 1, LENGTH (databasesize) - 3)))
            databasesize
    FROM qrdba_db_size
GROUP BY TO_CHAR (cr_date, 'MON-YYYY')
ORDER BY TO_DATE (TO_CHAR (cr_date, 'MON-YYYY'), 'MON-YYYY');

SELECT * FROM QRDBA_TS_FREE_SPACE;


SELECT TO_CHAR (cr_date, 'MON-YYYY') Month, tsname,  ceil(avg(sizemb)) FROM QRDBA_TS_FREE_SPACE
GROUP BY TO_CHAR (cr_date, 'MON-YYYY'),tsname
ORDER BY TO_DATE (TO_CHAR (cr_date, 'MON-YYYY'), 'MON-YYYY');

order by cr_date desc ;