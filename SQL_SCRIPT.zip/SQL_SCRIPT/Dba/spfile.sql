  SELECT name,
         LISTAGG (display_value, '|') WITHIN GROUP (ORDER BY display_value)
            enames
    FROM gv$parameter
   WHERE VALUE IS NOT NULL AND ISDEFAULT != 'TRUE'
GROUP BY name
/