select count(1) ,NODE_ID from icx_sessions where LAST_CONNECT > sysdate -1/96 group by NODE_ID;

select LIMIT_TIME,LIMIT_CONNECTS ,to_char(LAST_CONNECT,'dd-mon-yyyy hh-MI-ss'),NODE_ID from icx_sessions where LAST_CONNECT > sysdate -1/96
