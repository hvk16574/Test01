set feed off
set veri off
set lines 200
set term off
col ann new_value vann
col id90 new_value vid90
col id50 new_value vid50
col oth new_value voth
accept hello 
accept FLNUM

select count(1) ANN from alt_own_1058.STF_PAXDETAILS WHERE FDID = '&FLNUM&hello' and SUBSTR (priority, 1, 3) = '27Y';

select count(1) ID50 from alt_own_1058.STF_PAXDETAILS WHERE FDID = '&FLNUM&hello' and SUBSTR (priority, 1, 3) = '36Y';

select count(1) ID90 from alt_own_1058.STF_PAXDETAILS WHERE FDID = '&FLNUM&hello' and SUBSTR (priority, 1, 3) = '45Y';

select count(1) OTH from alt_own_1058.STF_PAXDETAILS WHERE FDID = '&FLNUM&hello' and SUBSTR (priority, 1, 3) not in ('27Y','36Y','45Y');

col stfcnt new_value scnt

SELECT count(1) stfcnt FROM alt_own_1058.STF_PAXDETAILS WHERE FDID = '&FLNUM&hello'; 

set term on
--select load_capturedate,LOAD_CONFIGC,LOAD_BOOKEDC,LOAD_CONFIGC-LOAD_BOOKEDC FREE_BCLASS,LOAD_CONFIGY,LOAD_BOOKEDY,LOAD_CONFIGY-LOAD_BOOKEDY FREE_ECLASS,LOAD_SEATAVAIL_C+LOAD_SEATAVAIL_Y SEAT_AVAIL, 
--(LOAD_SEATAVAIL_C+LOAD_SEATAVAIL_Y) - &scnt TOT_FREE, &scnt TOT_STAFF, ' [A:'||&vann||', 50:'||&vid50||', 90:'||&vid90||', O:'||&voth||']' TKT
--from alt_own_1058.FLIGHT_LOAD where fltid_key='&FLNUM&hello' and load_capturedate > = (select max(load_capturedate) from alt_own_1058.FLIGHT_LOAD where fltid_key='&FLNUM&hello')    
--order by load_capturedate desc;

select to_char(load_capturedate,'dd-mm-yyyy hh24:mi:ss')||chr(13)||'[CONF F:'||LOAD_CONFIGF||' C:'||LOAD_CONFIGC||' Y:'||LOAD_CONFIGY||'] '||chr(13)||'[BKB C:'||LOAD_BOOKEDF||' C:'||LOAD_BOOKEDC||' Y:'||LOAD_BOOKEDY||']'
||chr(13)||'[Avail F:'||(LOAD_CONFIGF-LOAD_BOOKEDF)||' C:'||(LOAD_CONFIGC-LOAD_BOOKEDC)||' Y:'||(LOAD_CONFIGY-LOAD_BOOKEDY)||'] '
||chr(13)||'[A:'||&vann||', 50:'||&vid50||', 90:'||&vid90||', O:'||&voth||']'
||chr(13)||'[Tot Avail:' ||(LOAD_SEATAVAIL_C+LOAD_SEATAVAIL_Y)||']'
||chr(13)||'[Tot Avail Staff:'||((LOAD_SEATAVAIL_C+LOAD_SEATAVAIL_Y) - &scnt)||']'
||chr(13)||'[Tot Staff:'|| &scnt||']' TKT
from alt_own_1058.FLIGHT_LOAD where fltid_key='&FLNUM&hello' and load_capturedate > = (select max(load_capturedate) from alt_own_1058.FLIGHT_LOAD where fltid_key='&FLNUM&hello')    
order by load_capturedate desc;