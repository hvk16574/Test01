SELECT USER_ID, USER_NAME FROM FND_USER WHERE USER_NAME = '23339';
--USER_ID =>31156

SELECT application_id, Responsibility_id, responsibility_name FROM FND_RESPONSIBILITY_VL
 WHERE responsibility_name LIKE 'System Administrator'
/

--RESPONSIBILITY_ID=>20420
--RESPONSIBILITY_APPLICATION_ID=>1

DECLARE
   l_request_id   NUMBER (30);
BEGIN
   FND_GLOBAL.APPS_INITIALIZE (user_id        => 31156, resp_id        => 20420, resp_appl_id   => 1);
   l_request_id := FND_REQUEST.SUBMIT_REQUEST ('FND', 'FNDSCURS');
   DBMS_OUTPUT.PUT_LINE (l_request_id);
   COMMIT;
END;
/
--select CONCURRENT_PROGRAM_NAME, APPLICATION_SHORT_NAME from fnd_concurrent_programs_vl fcp, fnd_application fa
--where fa.application_id = fcp.application_id
--and USER_CONCURRENT_PROGRAM_NAME = 'Active Users'