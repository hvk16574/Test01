-- What resource is currently in high demand
SELECT   active_session_history.event,
         SUM (  active_session_history.wait_time
              + active_session_history.time_waited
             ) ttl_wait_time
    FROM v$active_session_history active_session_history
   WHERE active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880
                                                AND SYSDATE
GROUP BY active_session_history.event
ORDER BY 2 desc;

-- What user is waiting the most
SELECT   sesion.SID, sesion.username,
         SUM (  active_session_history.wait_time
              + active_session_history.time_waited
             ) ttl_wait_time
    FROM v$active_session_history active_session_history, v$session sesion
   WHERE active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880
                                                AND SYSDATE
     AND active_session_history.session_id = sesion.SID
GROUP BY sesion.SID, sesion.username
ORDER BY 3 desc;

--What SQL is currently using the most resources
SELECT   active_session_history.user_id, dba_users.username, sqlarea.sql_text,
         SUM (  active_session_history.wait_time
              + active_session_history.time_waited
             ) ttl_wait_time
    FROM v$active_session_history active_session_history,
         v$sqlarea sqlarea,
         dba_users
   WHERE active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880
                                                AND SYSDATE
     AND active_session_history.sql_id = sqlarea.sql_id
     AND active_session_history.user_id = dba_users.user_id
GROUP BY active_session_history.user_id, sqlarea.sql_text, dba_users.username
ORDER BY 4 desc;

--What object is currently causing the highest resource waits
SELECT   dba_objects.object_name, dba_objects.object_type,
         active_session_history.event,
         SUM (  active_session_history.wait_time
              + active_session_history.time_waited
             ) ttl_wait_time
    FROM v$active_session_history active_session_history, dba_objects
   WHERE active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880
                                                AND SYSDATE
     AND active_session_history.current_obj# = dba_objects.object_id
GROUP BY dba_objects.object_name,
         dba_objects.object_type,
         active_session_history.event
ORDER BY 4 desc;