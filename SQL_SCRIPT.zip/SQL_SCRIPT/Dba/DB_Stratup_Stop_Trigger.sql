CREATE TABLE SYSTEM.DB_UPTIME
(
  INSTANCE_NAME  VARCHAR2(16 BYTE),
  ACTION_DATE    DATE,
  ACTION         VARCHAR2(20 BYTE)
) TABLESPACE USERS
;


CREATE UNIQUE INDEX SYSTEM.DB_UPTIME_U1 ON SYSTEM.DB_UPTIME
(ACTION_DATE) TABLESPACE USERS;

CREATE OR REPLACE TRIGGER SYSTEM.db_start
   AFTER STARTUP
   ON DATABASE
/* Database Trigger for Uptime Montoring */
DECLARE
   l_lastactiondate    db_uptime.action_date%TYPE;
   l_lastaction        db_uptime.action%TYPE;
   l_lastscntime       sys.smon_scn_time.TIME_DP%TYPE;
   l_thisstartuptime   v$instance.startup_time%TYPE;
   l_thisinstancename  v$instance.instance_name%TYPE;

   CURSOR c_heartbeat (v_prevstartup date, v_thisstartup date)
   IS
        SELECT   TIME_DP
          FROM   sys.smon_scn_time
         WHERE   TIME_DP > v_prevstartup AND time_dp < v_thisstartup
      ORDER BY   TIME_DP DESC;
BEGIN
   BEGIN
      SELECT   action_date, action
        INTO   l_lastactiondate, l_lastaction
        FROM   db_uptime
       WHERE   action_date = (SELECT   MAX (action_date) FROM db_uptime);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         l_lastaction := 'Startup';
         l_lastactiondate := TO_DATE ('01-Jan-1950', 'DD-Mon-YYYY');
   END;

   SELECT   startup_time,instance_name INTO l_thisstartuptime,l_thisinstancename  FROM v$instance;

   IF (l_lastaction = 'Startup')
   THEN                    /* Abort has occured, get the last SMON SCN Time */
    OPEN c_heartbeat(l_lastactiondate, l_thisstartuptime);

      FETCH c_heartbeat INTO   l_lastscntime;

      WHILE (c_heartbeat%FOUND AND l_lastscntime >= l_thisstartuptime - 5 / 86400)
      LOOP
         FETCH c_heartbeat INTO   l_lastscntime;
      END LOOP;

      IF (c_heartbeat%NOTFOUND)
      THEN                                       /* SMON SCN Time not found */
         l_lastscntime := l_thisstartuptime - 5 / 86400;
      END IF;

      CLOSE c_heartbeat;

      sys.DBMS_SYSTEM.ksdwrt (2,'ORA-DBDown: Shutdow Abort at '|| TO_CHAR ( (l_lastscntime + 1 / 86400), 'dd/mm/yyyy hh24:mi:ss')|| ' of instance : '||l_thisinstancename);

      INSERT INTO db_uptime VALUES   (l_thisinstancename,l_lastscntime + 1 / 86400, 'Abort');
   END IF;

   /* Purge records older than 500 days but leave atleast 1 record */
   DELETE FROM   db_uptime
         WHERE   action_date < SYSDATE - 1825
                 AND EXISTS (SELECT 1 FROM   db_uptime WHERE   action_date >= SYSDATE - 1825);

   sys.DBMS_SYSTEM.ksdwrt (2,'ORA-DBUP: Started at '|| TO_CHAR (l_thisstartuptime, 'dd/mm/yyyy hh24:mi:ss')|| ' of instance : '||l_thisinstancename);

   INSERT INTO db_uptime VALUES (l_thisinstancename, l_thisstartuptime, 'Startup');
END;
/

CREATE OR REPLACE TRIGGER SYSTEM.db_stop
   BEFORE SHUTDOWN
   ON DATABASE
DECLARE
   l_thisinstancename   v$instance.instance_name%TYPE;
BEGIN
   SELECT   instance_name INTO l_thisinstancename FROM v$instance;

   SYS.DBMS_SYSTEM.ksdwrt (
      2,
         'ORA-DBDown: Shutdown at '
      || TO_CHAR (SYSDATE, 'dd/mm/yyyy hh24:mi:ss')
      || ' of instance : '
      || l_thisinstancename
   );

   INSERT INTO db_uptime
     VALUES   (l_thisinstancename, SYSDATE, 'Shutdown');
END;
/

