UPDATE fnd_user fu
   SET fu.email_address =
          (SELECT papf.email_address
             FROM per_all_people_f papf
            WHERE employee_number = fu.user_name
              AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date)
 WHERE email_address IS NULL;

UPDATE fnd_user fu
   SET email_address =
          (SELECT pac.segment1
             FROM per_analysis_criteria pac
            WHERE pac.analysis_criteria_id = (
                     SELECT ppa.analysis_criteria_id
                       FROM per_person_analyses ppa
                      WHERE ppa.person_id =
                               (SELECT papf.person_id
                                  FROM per_all_people_f papf
                                 WHERE employee_number = fu.user_name
                                   AND TRUNC (SYSDATE)
                                          BETWEEN papf.effective_start_date
                                              AND papf.effective_end_date)and rownum < 2)
              AND pac.segment1 LIKE '%@%')
 WHERE fu.user_name IN (SELECT user_name
                          FROM fnd_user
                         WHERE email_address IS NULL )