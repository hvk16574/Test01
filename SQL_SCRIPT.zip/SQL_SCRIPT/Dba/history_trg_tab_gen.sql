SET SERVEROUTPUT ON SIZE 500000
SET FEEDBACK OFF

DECLARE
    lv_precision_and_scale   VARCHAR2 (20);
    CURSOR ctabhis IS
        SELECT table_name FROM dba_tables
         WHERE     SUBSTR (table_name, 1, 26) || '$HIS' NOT IN (SELECT table_name FROM dba_tables)
               AND table_name NOT LIKE '%$HIS' AND owner = 'SYSTEM' AND table_name = 'AUDIT_IP';

    CURSOR ccolhis ( p_tabhis    DBA_TABLES.TABLE_NAME%TYPE) IS
          SELECT column_name, data_type, data_length, data_precision, data_scale FROM dba_tab_columns
           WHERE     table_name = p_tabhis AND owner = 'SYSTEM' AND data_type NOT IN ('BLOB', 'CLOB', 'RAW')
        ORDER BY column_id;
BEGIN
    FOR ctabhis_row IN ctabhis
    LOOP
        DBMS_OUTPUT.PUT_LINE ( 'CREATE TABLE ' || SUBSTR (ctabhis_row.table_name, 1, 26)|| '$HIS (');
        FOR ccolhis_row IN ccolhis (ctabhis_row.table_name)
        LOOP
            IF ccolhis_row.data_type = 'NUMBER' THEN
                IF ccolhis_row.data_precision IS NULL THEN
                    lv_precision_and_scale := '38,0)';
                ELSE
                    lv_precision_and_scale := ccolhis_row.data_precision || ',' || ccolhis_row.data_scale || ')';
                END IF;
                DBMS_OUTPUT.PUT_LINE ( RPAD (ccolhis_row.column_name, 35) || ccolhis_row.data_type || '(' || lv_precision_and_scale || ',');
            ELSIF ccolhis_row.data_type IN ('CHAR', 'VARCHAR', 'VARCHAR2') THEN
                DBMS_OUTPUT.PUT_LINE ( RPAD (ccolhis_row.column_name, 35) || ccolhis_row.data_type || '(' || ccolhis_row.data_length || '),');
            ELSE
                DBMS_OUTPUT.PUT_LINE ( RPAD (ccolhis_row.column_name, 35) || ccolhis_row.data_type || ',');
            END IF;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE ( RPAD('HIS_DML',35) || 'VARCHAR(3),');
        DBMS_OUTPUT.PUT_LINE ( RPAD('HIS_TIMESTAMP',35) || 'DATE,');
        DBMS_OUTPUT.PUT_LINE ( RPAD('HIS_USER',35) || 'VARCHAR2(30) ,');
        DBMS_OUTPUT.PUT_LINE ( RPAD('HIS_OSUSER',35) || 'VARCHAR2(30) )');
        DBMS_OUTPUT.PUT_LINE ('/');
    END LOOP;
END;
/