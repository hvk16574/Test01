SELECT DISTINCT
       entity_name,
       (SELECT SUM (DBMS_LOB.GETLENGTH (file_data) / 1024 / 1024)
          FROM fnd_lobs a
         WHERE file_id IN
                  (SELECT MEDIA_ID
                     FROM fnd_documents
                    WHERE DOCUMENT_ID IN (SELECT DOCUMENT_ID
                                            FROM fnd_attached_documents
                                           WHERE entity_name = a.entity_name)))
          SIZE_MB
  FROM fnd_attached_documents a;