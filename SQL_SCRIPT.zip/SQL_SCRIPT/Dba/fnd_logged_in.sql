 select sid, serial#, context,
          round(sofar/DECODE(totalwork,0,sofar,totalwork)*100,2) "% Complete",
          substr(to_char(sysdate,'yymmdd hh24:mi:ss'),1,15) "Time Now",
          elapsed_seconds
   from   v$session_longops
   where  substr(opname,1,4)='RMAN';   
   
column sid form 99999
column spid for a5 heading "Unix|Serv|Pid" trunc 
column logon_time format a13

column user_name form a12 heading "Apps User"
column description form a35 heading "Description" wrap

select s.SID, p.SPID, to_char(logon_time,'dd-mon hh24:mi')  logon_time
      , f.user_name, u.description, S.TERMINAL, S.MACHINE
from gv$session s, gv$process p, FND_SIGNON_AUDIT_VIEW f, FND_USER u
where p.addr = s.paddr
and s.username is not null 
and f.process_spid = p.spid
and f.user_id = u.user_id
/ 