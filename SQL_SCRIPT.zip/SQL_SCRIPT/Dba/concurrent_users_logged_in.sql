SELECT   distinct d.user_name, machine, b.sid, b.osuser, b.logon_time, 
              COUNT (DISTINCT d.user_name)
              machine, COUNT (DISTINCT d.user_name)
  FROM   apps.fnd_logins a, gv$session b, gv$process c, apps.fnd_user d
 WHERE       b.paddr = c.addr
         AND a.pid = c.pid
         AND a.spid = b.process
         AND d.user_id = a.user_id
         AND (d.user_name = 'USER_NAME' OR 1 = 1)
         AND a.end_time IS NULL
         AND a.login_type IS NOT NULL
--         and d.user_name = :emp_no
         group by  machine
         , d.user_name, b.sid, b.osuser, b.logon_time
         
SELECT   machine, COUNT (DISTINCT d.user_name)
  FROM   apps.fnd_logins a, gv$session b, gv$process c, apps.fnd_user d
 WHERE       b.paddr = c.addr
         AND a.pid = c.pid
         AND a.spid = b.process
         AND d.user_id = a.user_id
         AND (d.user_name = 'USER_NAME' OR 1 = 1)
         AND a.end_time IS NULL
         AND a.login_type IS NOT NULL
--         and  last_call_et < 3600 * .01
--         and d.user_name = :emp_no
         group by  machine