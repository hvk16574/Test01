SELECT /*+RULE */  'alter system kill session '||''''||SID||','|| serial#||''' immediate;'
  FROM v$session
 WHERE SID IN (SELECT /*+RULE */  SID
                 FROM v$access
                WHERE OBJECT LIKE 'QR_SSHR_LEAVE_ABSENCES')