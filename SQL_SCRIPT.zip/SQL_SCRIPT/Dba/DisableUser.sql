DECLARE
   fname   VARCHAR2 (100);
   oname   VARCHAR2 (100);
   x_user_name varchar2(30) := lpad(trunc(:x_user_name),5,'0'); 
BEGIN
   /*SELECT   full_name INTO   fname FROM   per_all_people_f WHERE   employee_number = :x_user_name AND TRUNC (SYSDATE) BETWEEN effective_start_date AND  effective_end_date;*/
   SELECT   papf.full_name, HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id)
     INTO   fname, oname
     FROM   per_all_people_f papf, per_all_assignments_f paaf
    WHERE   papf.employee_number = x_user_name
            AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date AND  papf.effective_end_date
            AND papf.person_id = paaf.person_id
            AND TRUNC (SYSDATE) BETWEEN Paaf.effective_start_date AND  Paaf.effective_end_date;

   DBMS_OUTPUT.put_line ('Employee Disabled : ' || x_user_name || ' : ' || fname || ' : ' || oname );

   apps.fnd_user_pkg.updateuser (
      x_user_name,
      x_owner         => 0,
      x_end_date      => SYSDATE,
      x_description   =>   'Resigned, disbaled on ' || SYSDATE || ' - Hamid V. Khan');
   COMMIT;
END;