WITH pivot_data  AS ( SELECT TO_CHAR (CR_DATE, 'MON-YY') MONTH, segment_name, CEIL (AVG (SIZE_MB)) AVG
                      FROM DBREPORT.QRDBA_Segment_SIZE
                      where owner = 'FRM'
                      GROUP BY TO_CHAR (CR_DATE, 'MON-YY'), segment_name
                      ORDER BY TO_DATE (TO_CHAR (CR_DATE, 'MON-YY'), 'MON-YY') DESC)
SELECT *
  FROM pivot_data PIVOT (SUM (AVG)                          --<-- pivot_clause
                  FOR month                             --<-- pivot_for_clause
                  IN
                  ('DEC-16','NOV-16','OCT-16','SEP-16','AUG-16','JUL-16','JUN-16','MAY-16','APR-16','MAR-16','FEB-16','JAN-16',
                   'DEC-15','NOV-15','OCT-15','SEP-15','AUG-15','JUL-15','JUN-15','MAY-15','APR-15','MAR-15','FEB-15','JAN-15',
                   'DEC-14','NOV-14','OCT-14','SEP-14','AUG-14','JUL-14','JUN-14','MAY-14','APR-14','MAR-14','FEB-14','JAN-14'));
                   
                   
                   
                   
                   