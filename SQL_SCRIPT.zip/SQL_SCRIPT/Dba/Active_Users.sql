SELECT   papf.employee_number, papf.full_name
       , ( SELECT NAME
            FROM per_grades
           WHERE grade_id = paaf.grade_id
             AND ROWNUM = 1 ) grade, ppd.segment1 POSITION, haou.NAME dept
       , responsibility_name, frt.description resp_description
       , furg.start_date responsibility_start_date
       , furg.end_date responsibility_end_date
    FROM fnd_user_resp_groups_direct furg
       , fnd_user fu
       , fnd_responsibility_tl frt
       , per_all_people_f papf
       , per_all_assignments_f paaf
       , hr_all_organization_units haou
       , hr_all_positions_f hapf
       , per_position_definitions ppd
   WHERE fu.user_id = furg.user_id
     AND frt.responsibility_id = furg.responsibility_id
     AND papf.person_id = paaf.person_id
     AND papf.person_id = fu.employee_id
     --AND fu.user_name = '21873'
     AND haou.organization_id = paaf.organization_id
     AND paaf.position_id = hapf.position_id
     AND hapf.position_definition_id = ppd.position_definition_id
     AND SYSDATE BETWEEN papf.effective_start_date AND papf.effective_end_date
     AND SYSDATE BETWEEN paaf.effective_start_date AND paaf.effective_end_date
     AND SYSDATE BETWEEN hapf.effective_start_date AND hapf.effective_end_date
ORDER BY papf.employee_number
