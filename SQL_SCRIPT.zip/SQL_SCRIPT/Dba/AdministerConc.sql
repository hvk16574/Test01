SELECT  user_concurrent_queue_name,
        max_processes, running_processes
    FROM fnd_concurrent_queues_vl
   WHERE enabled_flag = 'Y' and control_code is null
   and max_processes != running_processes
ORDER BY DECODE (application_id, 0, DECODE (concurrent_queue_id, 1, 1, 4, 2)),
         SIGN (max_processes) DESC,
         concurrent_queue_name,
         application_id