SELECT distinct fu.user_name,
       fu.description,
       decode(fu.employee_id, null, null, 'Yes') EMPLOYEE,
       decode(fu.customer_id, null, null, 'Yes') CUSTOMER,
       decode(fu.supplier_id, null, null, 'Yes') SUPPLIER,
       frt.responsibility_name,
       trunc(fur.start_date) start_date,
       fur.end_date
  FROM APPS.FND_USER_RESP_GROUPS_DIRECT fur, --fnd_user_resp_groups fur,
       applsys.fnd_user fu,
       applsys.fnd_responsibility_tl frt
 WHERE fur.user_id = fu.user_id
   and fur.responsibility_application_id = frt.application_id
   and fur.responsibility_id             = frt.responsibility_id
   and (fur.end_date is null or fur.end_date > sysdate )
   and (fu.end_date is null or fu.end_date > sysdate )
   and fu.user_name != 'SYSADMIN'
ORDER by fu.user_name, frt.responsibility_name ;

---------------------------------------------------------------
  SELECT   DISTINCT fu.user_name,
                    fu.description,
                    DECODE (fu.employee_id, NULL, NULL, 'Yes') EMPLOYEE,
                    DECODE (fu.customer_id, NULL, NULL, 'Yes') CUSTOMER,
                    DECODE (fu.supplier_id, NULL, NULL, 'Yes') SUPPLIER,
                    frt.responsibility_name,
                    TRUNC (fur.start_date) start_date,
                    fur.end_date,substr(pp.name,1,instr(pp.name,'|',1) -1) designation,
                    hr_general.decode_location (paf.location_id) location,
                    hr_general.decode_organization(paf.organization_id) Organization
    FROM   APPS.FND_USER_RESP_GROUPS_DIRECT fur,
           applsys.fnd_user fu,
           applsys.fnd_responsibility_tl frt,
           per_all_people_f papf,
           per_all_assignments_f paf, per_positions pp
   WHERE       fur.user_id = fu.user_id
           AND fur.responsibility_application_id = frt.application_id
           AND fur.responsibility_id = frt.responsibility_id
           AND (fur.end_date IS NULL OR fur.end_date > SYSDATE)
           AND (fu.end_date IS NULL OR fu.end_date > SYSDATE)
           AND fu.user_name != 'SYSADMIN'
           AND fu.user_name = papf.employee_number 
           AND papf.person_id = paf.person_id
           AND SYSDATE BETWEEN Papf.effective_start_date AND Papf.effective_end_date
           AND SYSDATE BETWEEN Paf.effective_start_date AND Paf.effective_end_date
           AND current_employee_flag = 'Y'
           AND paf.primary_flag = 'Y'
--           and fu.user_name = '23339'
           and PP.POSITION_ID = paf.position_id
ORDER BY   fu.user_name, frt.responsibility_name;