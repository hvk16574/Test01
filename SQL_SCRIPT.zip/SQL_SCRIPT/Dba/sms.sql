--select * from sms_users

create table sms_users
(
 user_id number primary key,
 fname varchar2(30 byte) not null,
 mname varchar2(30 byte),
 lname varchar2(30 byte),
 email varchar2(50 byte) not null,
 cell_no varchar2(20 byte) not null
);


insert into sms_users values (0, 'sysadmin', 'sysadmin', 'sysadmin', 'sysadmin', '0123456789');
insert into sms_users values (1, 'Hamid', 'Vahid', 'Khan', 'hkhan@qatarairways.com.qa', '97455565927');


create table technology
(
tech_id number primary key,
description varchar2(80) not null
);

insert into technology values (0, 'Oracle ERP');
insert into technology values (1, 'Oracle Core');
insert into technology values (2, 'Oracle MySQL');
insert into technology values (3, 'Microsoft SQLServer');


create table user_access
(
user_id number not null, 
tech_id number not null,
constraint fk_ua_uid foreign key (user_id) references sms_users (user_id),
constraint fk_ua_tid foreign key (tech_id) references technology (tech_id)
);

insert into user_access values (0, 0);
insert into user_access values (0, 1);
insert into user_access values (0, 2);
insert into user_access values (0, 3);
insert into user_access values (1, 0);
insert into user_access values (1, 1);

create table tech_apprv
(
tech_id number not null,
approver_id number not null,
constraint fk_ta_uid foreign key (approver_id) references sms_users (user_id),
constraint fk_ta_tid foreign key (tech_id) references technology (tech_id)
);

insert into tech_apprv values   (0, 1);
insert into tech_apprv values   (1, 1);