CREATE TABLE applsys.fnd_profile_option_values_1
AS SELECT * FROM fnd_profile_option_values;

SELECT * FROM fnd_profile_options
 WHERE profile_option_id = 10126;

SELECT * FROM fnd_profile_option_values
 WHERE PROFILE_OPTION_ID = 10126;

SELECT * FROM fnd_nodes;

SELECT * FROM fnd_profile_options
 WHERE profile_option_id IN (SELECT profile_option_id FROM fnd_profile_option_values WHERE level_value2 = '129050');

SELECT * FROM fnd_profile_options_tl
 WHERE PROFILE_OPTION_NAME IN (SELECT PROFILE_OPTION_NAME FROM fnd_profile_options
                                WHERE profile_option_id IN (SELECT DISTINCT PROFILE_OPTION_ID FROM fnd_profile_option_values
                                                             WHERE level_value2 IN (SELECT node_id FROM fnd_nodes)))