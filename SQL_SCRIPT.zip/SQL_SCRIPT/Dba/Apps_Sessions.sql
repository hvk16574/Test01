SELECT ((SELECT SYSDATE
           FROM DUAL)),
       (SELECT ' user sessions : ' || COUNT (DISTINCT session_id) how_many_user_sessions
          FROM icx_sessions icx
         WHERE disabled_flag != 'Y' AND pseudo_flag = 'N' AND (last_connect + DECODE (fnd_profile.VALUE ('ICX_SESSION_TIMEOUT'), NULL, limit_time, 0, limit_time, fnd_profile.VALUE ('ICX_SESSION_TIMEOUT') / 60) / 24) > SYSDATE
               AND counter < limit_connects) abc
  FROM DUAL;

SELECT COUNT (DISTINCT d.user_name)
  FROM apps.fnd_logins a, v$session b, v$process c, apps.fnd_user d
 WHERE b.paddr = c.addr AND a.pid = c.pid AND a.spid = b.process AND d.user_id = a.user_id AND (d.user_name = 'USER_NAME' OR 1 = 1);

SELECT COUNT (DISTINCT user_id) "users"
  FROM icx_sessions
 WHERE last_connect > SYSDATE - 1 / 24 AND user_id != '-1';

SELECT COUNT (DISTINCT user_id) "users"
  FROM icx_sessions
 WHERE last_connect > SYSDATE - 1 AND user_id != '-1';

SELECT limit_time, limit_connects, TO_CHAR (last_connect, 'DD-MON-RR HH:MI:SS') "Last Connection time", user_id, disabled_flag
  FROM icx_sessions
 WHERE last_connect > SYSDATE - 1 / 96;