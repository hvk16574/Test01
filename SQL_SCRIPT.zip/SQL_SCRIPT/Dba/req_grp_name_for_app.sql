SELECT   *
  FROM   FND_REQUEST_GROUPS
 WHERE   REQUEST_GROUP_ID in
            (SELECT   REQUEST_GROUP_ID
               FROM   FND_REQUEST_GROUP_UNITS
              WHERE   REQUEST_UNIT_ID =
                         (SELECT   CONCURRENT_PROGRAM_ID
                            FROM   FND_CONCURRENT_PROGRAMS_Vl
                           WHERE   CONCURRENT_PROGRAM_NAME = 'PAYDYNDBIGEN'));
                           
SELECT distinct 
     frg.request_group_name
  FROM applsys.fnd_responsibility fr,
       applsys.fnd_responsibility_tl frt,
       applsys.fnd_user fua,
       applsys.fnd_user fub,
       applsys.fnd_menus_tl fmt,
       applsys.fnd_request_groups frg,
       applsys.fnd_application_tl fata,
       applsys.fnd_data_groups fdg,
       applsys.fnd_application_tl fatb
 WHERE fr.application_id = frt.application_id
   and fr.responsibility_id = frt.responsibility_id
   and fr.created_by = fua.user_id(+)
   and fr.last_updated_by = fub.user_id(+)
   and fr.menu_id = fmt.menu_id(+)
   and fmt.language(+) = userenv('LANG')
   and fr.group_application_id = frg.application_id(+)
   and fr.request_group_id = frg.request_group_id(+)
   and fr.group_application_id = fata.application_id(+)
   and fata.language(+) = userenv('LANG')
   and fr.data_group_id = fdg.data_group_id(+)
   and fr.data_group_application_id = fatb.application_id(+)
   and fatb.language(+) = userenv('LANG')
   and fr.application_id = 200;