DECLARE
   CURSOR c1
   IS
        select 
b.CONCURRENT_PROGRAM_NAME,c.APPLICATION_SHORT_NAME 
from fnd_concurrent_programs_tl a,fnd_concurrent_programs b, fnd_application c 
where
b.CONCURRENT_PROGRAM_ID = a.CONCURRENT_PROGRAM_ID and
c. application_id = a.application_id and 
a.USER_CONCURRENT_PROGRAM_NAME in ('QAG Pay Quickpay Report',
'DI Negative Results for Checking',
'QU Payroll Cash Salary',
'DI Payroll Cash Salary - Excel',
'QF Payroll Bank Transfer Letter (For Monthly Payroll) -QNB_JC',
'QAG Bank Soft Copy(QATCH Payment Format) - JAMOCHA',
'QS Payroll Bank Transfer Letter (For Monthly Payroll) - CBQ -XML',
'Cash',
'Costing',
'Rollback',
'Rollback Run',
'Transfer to GL',
'PrePayments',
'Payroll Run',
'QR HR Head Count Report (Ver 1.0)',
'QC Payroll Results For Checking',
'QC Payroll Cash Salary',
'QC HR Head Count Report (Ver 1.0)',
'QC Pay Advice Report for IBQ',
'QC Payroll Bank Disbursement Report',
'DI Payroll Results For Checking',
'DI Pay Soft Copy For CBQ',
'DI Payroll Bank Transfer Letter (For Monthly Payroll) - CBQ',
'DI Payroll Cash Salary',
'DI Payroll Summary (Cost Centerwise)',
'DI Payroll Summary (By Employee - Typewise)',
'DI Payroll Bank Disbursement Report',
'QD Payroll Cash Salary',
'QF Pay Disbursement Report',
'QF Payroll Bank Transfer Letter (For Monthly Payroll) -CBQ',
'QF Payroll Cash Salary',
'QS Payroll Bank Transfer Letter (For Monthly Payroll) - CBQ',
'QS Payroll Bank Disbursement Report',
'QS Payroll Cash Salary',
'QS Payroll Results For Checking',
'QD Pay Disbursement Report',
'DI HR Head Count Report (Ver 1.0)',
'QD HR Head Count Report (Ver1.0)',
'QF Head Count Report Ver1.0',
'QD Payroll Bank Transfer Letter( Form Monthly Payroll with Bank Details) - IBQ',
'QU Payroll Results For Checking',
'QS Head Count Report (Ver 1.0)',
'QU Payroll Bank Transfer Letter (For Monthly Payroll) -CBQ',
'QS Payroll Summary (By Cost Center)',
'QS Payroll Summary (By Employee)',
'QS Payroll Summary (Cost Centerwise)',
'QF Pay Reconcilation Summary Report',
'QD Pay Reconcilation Summary Report',
'QAG HR Etravel DSD Reconciliation Report',
'QAG Staff Multiple Bank details - PDF',
'QAG Staff Bank details - Not Updated in system',
'QR Payroll Summary (By Employee)',
'QR Payroll Summary (By Cost Center)',
'QR Pay Advice (Bank Transfer Payments)',
'QR Payroll Bank Transfer Letter (For Monthly Payroll)',
'QR Payroll Cash Salary',
'QR Payroll Bank Disbursement Report',
'QR Pay Advice (Cash Payments - Individual)',
'QR Payroll Results For Checking',
'QR Pay All Advances Balance (As of Given Date)',
'QR Pay Payment Entries Report',
'QR Pay Negative Salary Report',
'QR Employee Head Count Report',
'QR Payroll Summary (By Employee - Typewise)',
'QR Payroll Summary (Cost Centerwise)',
'QR Pay Quick Pay Results',
'DI Payroll Summary (Cost Centerwise)',
'QF Negative Payment Report',
'QS Negative Results For Checking',
'QD Negative Payment Report',
'QAG Online Payslip Report (Super User)',
'QAG Payroll Element Wise Report',
'QAG Payroll Element Wise Report (Excel)',
'QAG Online Payslip Publish Payroll Program',
'QAG Bank Letter Report',
'QAG EOSB Payment Letter',
'QAG Payroll Headcount and Costwise',
'QAG Payroll Monthly Gratuity',
'QS Pay Quick Pay Results',
'QAG Pay Duty Travel Payment Letter',
'QAG Bank Soft Copy(QATCH Payment Format)',
'QAG Pay Advice(Bank Transfer Payments) - Salary Advance',
'QR Pay Employee Headcount Report',
'QAG Pay Pension Report',
'DI Negative Results for Checking',
'QAG Audit Trial Report',
'QAG HR Overtime Comparison Report',
'QAG HR Overtime Payment Report',
'QAG HR Overtime Month Wise Comparison Report',
'QAG HR Payroll Staff Movement Head Count Report',
'QAG HR GEMS Employee Payslip Interface Program',
'QAG Duty Travel Payment Letter',
'QR Payroll Cash Salary - Excel',
'QAG Payroll Element Audit Report - FInance Payroll',
'QAG Payroll Exception Report - Recurring Element',
'QAG Payroll Exception Report - Non-Recurring',
'QAG Payroll Exception Report - Batch Entry',
'QAG Service Bond Payment Breakup Report',
'QAG Payroll Exception Report - Transport Allowance',
'QAG Payroll Exception Report - Utility Allowance',
'QAG Payroll Exception Report - Retro Elements',
'QAG All Elements Payment status - After Payroll',
'HIA Quick Pay Run Results',
'QR Payroll Bank Disbursement Report - Posted',
'QR Payroll Cash Salary - Posted',
'QAG Staff EOSB Payment Report',
'QAG HR Duplicate Bank Accounts - Exception Report',
'QAG HR Pay Advice (Bank Transfer Payments)',
'QAG HR Pay Advice (Bank Transfer Payments) - Superuser',
'QAG HR Pay Advice (Bank Transfer Payments) - Salary Advance',
'OH Payroll Bank Disbursement Report',
'OH Payroll Cash Salary - Excel',
'OH Pay Negative Salary Report',
'OH Payroll Results For Checking',
'OH Payroll Summary (By Cost Center)',
'OH Payroll Summary (By Employee - Typewise)',
'OH Payroll Bank Transfer Letter (For Monthly Payroll) - CBQ',
'OH Pay Quick Pay Results',
'QAG HR Bank Soft Copy QATCH ( JAMOCHA )',
'OH Payroll Cash Salary',
'OH Pay Employee Headcount Report',
'QAG Payroll Quickpay Payment report',
'QAG HR Pay Negative Salary Report',
'QAG HR Uncleared Quick Pay Employee List',
'QS Payroll Bank Transfer Letter (For Monthly Payroll) - CBQ -XML',
'OH Payroll Cash Salary - Bank Format',
'DI Payroll Cash Salary - Bank Format',
'QR Payroll Cash Salary - Bank Format',
'QAG HR GEMS Second Payslip Interface Program',
'QR Payroll Summary - Employee Typewise',
'QAG Bank Soft Copy(QATCH Payment Format-XML)',
'QC Pay Advice Report for IBQ (For Allowances)',
'QAG PAY HIA Settlement Summary Report (Kash el Taswea)',
'QAG PAY HIA Bank Letter ( Monthly Payroll)',
'QAG PAY HIA Actual Department Summary Report',
'QAG PAY HIA MOA Elementwise Summary Report',
'QAG PAY HIA Element Payment Report',
'QAG PAY QATCH HIA Bank Transfer Report',
'QAG PAY HIA Pension Summary Report',
'QAG Pay Advice - Bank Transfer Payments',
'QAG Pay Advice - Bank Transfer Payments (Superuser)',
'QU Payroll Bank Disbursement Report');

   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER := NULL;
   x_start_date                   DATE := SYSDATE;
   x_end_date                     DATE := NULL;
   x_last_logon_date              DATE := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE := NULL;
   x_password_accesses_left       NUMBER := NULL;
   x_password_lifespan_accesses   NUMBER := NULL;
   x_password_lifespan_days       NUMBER := NULL;
   x_employee_id                  NUMBER := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER := NULL;
   x_supplier_id                  NUMBER := NULL;
   x_res_id                       VARCHAR2 (80) := NULL;
   x_ai                           VARCHAR2 (80) := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      fnd_manager.specialize ('STANDARD-ErpAppHR1', 'FND','include','Program',
                               c1_rec.CONCURRENT_PROGRAM_NAME,
                               c1_rec.APPLICATION_SHORT_NAME,
                               SYSDATE, 0);
--      DBMS_OUTPUT.put_line ('Responsibility: ' || c1_rec.res || ' Endated to Staff#:' || c1_rec.EMPLOYEE_NUMBER);
   END LOOP;
END;