delete from ra_interface_lines_all where INTERFACE_LINE_CONTEXT = 'FALCON';
delete from ra_interface_distributions where INTERFACE_LINE_CONTEXT = 'FALCON';
truncate table qr_rapid.qr_fal_ar_lines_temp;
truncate table qr_rapid.qr_fal_ar_header_temp;

----------------------------------------------------------------
ra_customer_interface

ra_contant_phones_interface

ra_customer_banks_interface

ra_customer_profiles_interface

ra_cust_pay_method_interface

Invoice interface tables:

ra_interface_lines_all

ra_interface_sales_credits

ra_interface_distributions

qr_fal_ar_header_temp 
qr_fal_ar_lines_temp 