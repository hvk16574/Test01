connect sys as sysdba
GRANT SELECT ON smon_scn_time TO SYSTEM;
GRANT SELECT ON v_$instance TO SYSTEM;
GRANT EXECUTE ON DBMS_SYSTEM TO SYSTEM;

connect system
CREATE TABLE db_uptime (action_date DATE, action VARCHAR2(20)) TABLESPACE users;
CREATE UNIQUE INDEX db_uptime_u1 ON db_uptime (action_date) TABLESPACE users;
INSERT INTO db_uptime
   SELECT startup_time action_date, 'Startup' action
     FROM v$instance;
Commit;

CREATE OR REPLACE TRIGGER db_start AFTER STARTUP ON DATABASE
/* Database Trigger for Uptime Montoring */
DECLARE
  l_lastactiondate    db_uptime.action_date%type;
  l_lastaction        db_uptime.action%type;
  l_lastscntime        sys.smon_scn_time.TIME_DP%TYPE;
  l_thisstartuptime    v$instance.startup_time%TYPE;

  cursor c_heartbeat (v_prevstartup date, v_thisstartup date) is
    select TIME_DP from sys.smon_scn_time
    where TIME_DP>v_prevstartup and time_dp<v_thisstartup
    order by TIME_DP desc;

BEGIN
  begin
    select action_date, action into l_lastactiondate, l_lastaction
      from db_uptime
    where action_date =
    ( select max(action_date) from db_uptime );
  exception
    when no_data_found then
      l_lastaction := 'Startup';
      l_lastactiondate := to_date('01-Jan-1950', 'DD-Mon-YYYY');
  end;

  select startup_time into l_thisstartuptime
  from v$instance;

  if (l_lastaction = 'Startup') then    /* Abort has occured, get the last SMON SCN Time */
    open c_heartbeat(l_lastactiondate, l_thisstartuptime);
    fetch c_heartbeat into l_lastscntime;
    while (c_heartbeat%found and l_lastscntime>=l_thisstartuptime-5/86400)
    loop
      fetch c_heartbeat into l_lastscntime;
    end loop;
    if (c_heartbeat%notfound) then    /* SMON SCN Time not found */
      l_lastscntime := l_thisstartuptime-5/86400;
    end if;
    close c_heartbeat;

    sys.dbms_system.ksdwrt(2,'ORA-DBDown: Shutdow Abort at '||l_lastscntime+1/86400 );
    insert into db_uptime values(l_lastscntime+1/86400,'Abort');
  end if;

  /* Purge records older than 500 days but leave atleast 1 record */
  delete from db_uptime
  where action_date < sysdate - 500
  and exists (select 1 from db_uptime where action_date >= sysdate - 500);
  sys.dbms_system.ksdwrt(2,'ORA-DBUP: Started at '||l_thisstartuptime );
  insert into db_uptime values(l_thisstartuptime,'Startup');
END;
/

CREATE OR REPLACE TRIGGER db_stop
   BEFORE SHUTDOWN ON DATABASE
BEGIN
   SYS.DBMS_SYSTEM.ksdwrt (2,'ORA-DBDown: Shutdown at '|| TO_CHAR (SYSDATE, 'dd/mm/yyyy hh24:mi:ss'));
   INSERT INTO db_uptime VALUES (SYSDATE, 'Shutdown');
END;
/
