SELECT FIRST_TIME, TO_CHAR (FIRST_TIME, 'hh24') FROM V$ARCHIVED_LOG;

  SELECT ARCH, COUNT (*)
    FROM (SELECT (CASE
                     WHEN TO_CHAR (FIRST_TIME, 'hh24') BETWEEN 0 AND 7 THEN 1
                     WHEN TO_CHAR (FIRST_TIME, 'hh24') BETWEEN 8 AND 15 THEN 2
                     ELSE 3
                  END)
                    AS ARCH
            FROM V$ARCHIVED_LOG)
GROUP BY ARCH;


 
WITH Arch
     AS (  SELECT TRUNC (first_time) "Date", TO_CHAR (first_time, 'Dy') "Day", ROUND (SUM ( (blocks * block_size) / 1024 / 1024)) SizeM, COUNT (1),
                  (CASE
                      WHEN TO_CHAR (FIRST_TIME, 'hh24') BETWEEN 0 AND 7 THEN '00-07'
                      WHEN TO_CHAR (FIRST_TIME, 'hh24') BETWEEN 8 AND 15 THEN '08-15'
                      ELSE '16-23'
                   END) batch
             FROM V$ARCHIVED_LOG
         GROUP BY TRUNC (first_time), TO_CHAR (first_time, 'Dy'),
                  (CASE
                      WHEN TO_CHAR (FIRST_TIME, 'hh24') BETWEEN 0 AND 7 THEN '00-07'
                      WHEN TO_CHAR (FIRST_TIME, 'hh24') BETWEEN 8 AND 15 THEN '08-15'
                      ELSE '16-23'
                   END))
  SELECT batch, MIN (sizem) MIN, MAX (sizem) MAX, ROUND (AVG (sizem)) AVG
    FROM Arch
GROUP BY batch
ORDER BY 4