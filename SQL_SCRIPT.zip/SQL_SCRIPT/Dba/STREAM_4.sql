select username from dba_users
minus

select distinct owner from dba_segments

select username from dba_users 
minus

select distinct owner from dba_segments where tablespace_name in (
'DD812I', 'DD812T', 'OL812I', 'OL812T', 'PD812I', 'PD812T', 'PRODCTLI', 'PRODCTLT', 'PRODDTAI', 'PRODDTAT', 'SVM812I', 'SVM812T', 'SY812I', 'SY812T')

select tablespace_name , sum(bytes)  from dba_data_files where 
tablespace_name in (
'DD812I', 'DD812T', 'OL812I', 'OL812T', 'PD812I', 'PD812T', 'PRODCTLI', 'PRODCTLT', 'PRODDTAI', 'PRODDTAT', 'SVM812I', 'SVM812T', 'SY812I', 'SY812T')
group by tablespace_name 

SELECT STATUS FROM DBA_APPLY WHERE APPLY_NAME = 'STREAM_APPLY';

COLUMN APPLY_NAME HEADING 'APPLY|Process|Name' FORMAT A10
COLUMN STATUS_CHANGE_TIME HEADING 'Abort Time'
COLUMN ERROR_NUMBER HEADING 'Error Number' FORMAT 99999999
COLUMN ERROR_MESSAGE HEADING 'Error Message' FORMAT A40

SELECT APPLY_NAME, STATUS_CHANGE_TIME, ERROR_NUMBER, ERROR_MESSAGE
  FROM DBA_APPLY WHERE STATUS='ABORTED';
  
COLUMN APPLY_CAPTURED HEADING 'Type of Messages Applied' FORMAT A25

SELECT DECODE(APPLY_CAPTURED,
                'YES', 'Captured',
                'NO',  'User-Enqueued') APPLY_CAPTURED
  FROM DBA_APPLY
  WHERE APPLY_NAME = 'STREAM_APPLY';  
  
  
  select * from DBA_APPLY_ERROR
  
  SELECT q.owner, q.name, t.queue_table, t.owner_instance
FROM DBA_QUEUES q, DBA_QUEUE_TABLES t
WHERE t.object_type = 'SYS.ANYDATA' AND
q.queue_table = t.queue_table AND
q.owner = t.owner;