SELECT fcpp.concurrent_request_id req_id, fcp.node_name, fcp.logfile_name
  FROM fnd_conc_pp_actions fcpp, fnd_concurrent_processes fcp
 WHERE fcpp.processor_id = fcp.concurrent_process_id
   AND fcpp.action_type = 6
   AND fcpp.concurrent_request_id = &&request_id;

  SELECT  CONCURRENT_PROCESS_ID, ORACLE_PROCESS_ID, OS_PROCESS_ID, PROCESS_START_DATE, GSM_INTERNAL_INFO,
         PROCESS_STATUS_CODE, CONCURRENT_QUEUE_ID, QUEUE_APPLICATION_ID
    FROM FND_CONCURRENT_PROCESSES
   WHERE (CONCURRENT_QUEUE_ID = 2120) AND (QUEUE_APPLICATION_ID = 0)
ORDER BY DECODE (Process_Status_Code, 'R', 1, 'T', 1, 'A', 2, 'P', 2, 'Z', 3, 'K', 3, 'S', 3, 'X', 3, 4), -TO_NUMBER (TO_CHAR (Last_Update_Date, 'YYYYMMDDSSSSS'));

select * from FND_CP_SERVICES
where SERVICE_ID in
  (select MANAGER_TYPE 
    from FND_CONCURRENT_QUEUES
   where CONCURRENT_QUEUE_NAME like 'FNDCPOPP%'); 
   
   
/*update FND_CP_SERVICES
set DEVELOPER_PARAMETERS = 'J:oracle.apps.fnd.cp.gsf.GSMServiceController:-mx2048m'
where SERVICE_ID =
  (select MANAGER_TYPE 
    from FND_CONCURRENT_QUEUES
   where CONCURRENT_QUEUE_NAME = 'FNDCPOPP'); */      
   
So like can i also add the below steps as par the document id *(The Output Post Processor does not process all requests. [ID 1399463.1])*

2. Run the script $FND_TOP/patch/115/sql/afopp001.sql as the SYSTEM user

3. Run the script $FND_TOP/patch/115/sql/afopp002.sql as the APPLSYS user .