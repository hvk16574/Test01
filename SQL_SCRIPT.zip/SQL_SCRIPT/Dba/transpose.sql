SELECT tablespace_name, RTRIM (EXTRACT (EXML, '//filename/text()'), ',') file_name
  FROM (  SELECT E.tablespace_name, XMLELEMENT ("dba_data_files", XMLAGG (XMLELEMENT ("filename", E.file_name || '|')
                            ORDER BY file_name)) EXML
            FROM dba_data_files E
           WHERE tablespace_name = 'SYSTEM'
        GROUP BY E.tablespace_name);

SELECT RTRIM (EXTRACT (EXML, '//filename/text()'), ',') username
  FROM (SELECT XMLELEMENT ( a, XMLAGG (XMLELEMENT ("filename", E.username || ',') ORDER BY username)) EXML
          FROM dba_users E);
                          
    SELECT tablespace_name, MAX (SUBSTR (SYS_CONNECT_BY_PATH (file_name, ','), 2)) new_col
      FROM (SELECT tablespace_name,file_name,ROW_NUMBER () OVER (PARTITION BY tablespace_name ORDER BY file_name)rno
              FROM dba_data_files WHERE tablespace_name = 'SYSTEM')
START WITH rno = 1
CONNECT BY rno = PRIOR rno + 1 AND PRIOR tablespace_name = tablespace_name
  GROUP BY tablespace_name
  ORDER BY tablespace_name;                          
  
SELECT RTRIM (XMLAGG (XMLELEMENT (e, user_name || ' ')).EXTRACT ('//text()'),' ')
  FROM fnd_user
 WHERE ROWNUM <= 10  