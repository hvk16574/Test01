--   Invoice Approval Pending
  SELECT rownum
       , a.*
    FROM (SELECT i.invoice_id 
               , papf.employee_number||' - '||INITCAP(papf.title ||' '||papf.first_name||' '||papf.last_name) Approver
               , SUBSTR (hap.NAME, 1, INSTR (hap.NAME, '|') - 1) "Position"
               , (SELECT TO_CHAR(comment_date, 'DD-Mon-RRRR HH24:MI:SS')
                    FROM (SELECT comment_date
                               , notification_id
                            FROM wf_comments c
                      ORDER BY c.comment_date DESC)
                   WHERE notification_id = n.notification_id
                     AND ROWNUM = 1) "WF Begin Date"
               , qr_ap_inv_appr_pend_days_f (n.notification_id) "Days"      
               , s.segment1 "Supplier"
               , s.vendor_name "Supplier Name"
               , i.invoice_num "Invoice No"
               , i.doc_sequence_value "Voucher No"
               , i.invoice_date "Invoice Date"
               , i.invoice_currency_code "Currency"
               , TRIM(TO_CHAR(i.invoice_amount,'999G999G999G990D00'))  "Amount"
               , i.description "Description"
               , n.notification_id
               , TO_CHAR(i.terms_date, 'DD-Mon-RRRR') "Term Date"
               , TO_CHAR(((i.terms_date) + tl.due_days), 'DD-Mon-RRRR') "Due Date"
            FROM wf_notifications n
               , ap_invoices_all i
               , ap_suppliers s
               , ap_supplier_sites_all ss
               , po_headers_all p
               , ap_terms t
               , ap_terms_lines tl
               , per_all_people_f papf
               , per_all_assignments_f paaf
               , hr_all_positions_f hap 
           WHERE 1 = 1
             AND s.vendor_id = i.vendor_id
             AND s.vendor_id = ss.vendor_id
             AND ss.vendor_site_id = i.vendor_site_id
             AND t.term_id = i.terms_id
             AND t.term_id = tl.term_id
             AND i.po_header_id = p.po_header_id (+)
             AND i.invoice_id = TO_NUMBER(SUBSTR (n.item_key, 1, INSTR (item_key, '_') - 1))
             AND n.message_type = 'APINVAPR'
--             AND NVL(n.more_info_role, n.recipient_role) = '33024'             
 AND n.status = 'OPEN'
             AND NVL(n.more_info_role, n.recipient_role) = papf.employee_number
             AND papf.person_id = paaf.person_id
             AND paaf.position_id = hap.position_id
             AND TRUNC(SYSDATE) BETWEEN TRUNC(hap.effective_start_date) AND TRUNC(hap.effective_end_date)
             AND TRUNC(SYSDATE) BETWEEN TRUNC(paaf.effective_start_date) AND TRUNC(paaf.effective_end_date)
             AND TRUNC(SYSDATE) BETWEEN TRUNC(papf.effective_start_date) AND TRUNC(papf.effective_end_Date)
        ORDER BY (SELECT comment_date
                    FROM (SELECT comment_date, notification_id
                            FROM wf_comments c
                      ORDER BY c.comment_date DESC)
                   WHERE notification_id = n.notification_id
                     AND ROWNUM = 1) DESC) a

--Rejected Invoice

SELECT INITCAP(papf1.first_name||' '||papf1.last_name) "Creator"
     , papf1.email_address "eMail"
     , s.segment1 "Supp.No" 
     , s.vendor_name "Supplier Name"
     , ai.invoice_num "Invoice No"
     , ai.doc_sequence_value "Voucher No."
     , INITCAP(papf2.title||' '||papf2.first_name||' '||papf2.last_name)||' ('||papf2.employee_number||')' "Action Taken By"
     , TO_CHAR(ias.end_date, 'DD-Mon-RRRR HH24:MI:SS') "Action Time"
     , (SELECT text_value
          FROM wf_notification_attributes
         WHERE notification_id = ias.notification_id
           AND NAME = 'WF_NOTE') "Comments"
  FROM per_all_people_f papf1
     , per_all_people_f papf2
     , ap_invoices_all ai
     , ap_suppliers s
     , fnd_user u
     , wf_item_activity_statuses ias
     , wf_activities a
     , wf_process_activities pa
     , wf_items i
     , wf_notifications n
WHERE ai.vendor_id = s.vendor_id
   AND u.user_id = ai.created_by
   AND papf1.person_id = u.employee_id  
   AND n.notification_id = ias.notification_id
   AND TRUNC (SYSDATE) BETWEEN papf1.effective_start_date AND papf1.effective_end_date
   AND papf2.employee_number = n.recipient_role
   AND n.message_type = 'APINVAPR'
   AND n.status = 'CLOSED'
   AND TRUNC (SYSDATE) BETWEEN papf2.effective_start_date AND papf2.effective_end_date
   AND ai.wfapproval_status = 'REJECTED'
   AND ias.notification_id IS NOT NULL
   AND ias.item_type = 'APINVAPR'
   AND ias.item_key = (ai.invoice_id || '_' || ai.approval_iteration)
   AND ias.item_type = i.item_type
   AND ias.item_key = i.item_key
   AND ias.activity_result_code IS NOT NULL
   AND i.begin_date BETWEEN a.begin_date AND NVL (a.end_date, i.begin_date)
   AND ias.process_activity = pa.instance_id
   AND pa.activity_name = a.name
   AND pa.activity_item_type = a.item_type
   AND ias.activity_result_code = 'REJECTED'
   AND ias.end_date >= (SYSDATE - 1);
