SELECT 
to_char(to_date(to_char(firsttimein,'99.09'),'hh24.mi')+((to_char(to_date(shiftreghrs,'hh24.mi'),'hh24')*60+to_char(to_date(to_char(shiftreghrs,'09.09'),'hh24.mi'),'mi')))/1440,'hh:mi AM') out,a.totalattnhrs,a.* FROM QRTAS.QRTAS_EMPLOYEE_OT_V@tna_to_erp a
 WHERE EMPLOYEECODE = :emp_num AND OFFDAY != -1 AND HOLIDAY != -1 AND TO_CHAR (ATTNDATE, 'MON-YYYY') = TO_CHAR (SYSDATE, 'MON-YYYY')                                                                                                         -- 'MAR-2013'
AND attndate NOT IN (
WITH   cntr        AS
( SELECT    LEVEL - 1    AS n FROM    dual
    CONNECT BY    LEVEL    <= ( SELECT  MAX (date_end - date_start) 
                    FROM    per_absence_attendances where person_id = (SELECT   DISTINCT person_id FROM   per_all_people_f
                WHERE   employee_number = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')),5,'0'))) + 1
)
SELECT x.date_start + c.n    AS a_date FROM      per_absence_attendances  x 
JOIN      cntr       c  ON  c.n  <= x.date_end - x.date_start
and x.person_id = (SELECT   DISTINCT person_id FROM   per_all_people_f
                WHERE   employee_number = LPAD (TRUNC (LPAD (TRUNC (:emp_num), 5, '0')),5,'0'))
)
ORDER BY 5 DESC;


SELECT MIN (EVENT_TIME_UTC + 3 / 24), MIN (EVENT_TIME_UTC + 3 / 24) + 8 / 24 + decode(to_char(sysdate,'D'),5,0,30/1440), MAX (EVENT_TIME_UTC + 3 / 24), MAX (EVENT_TIME_UTC + 3 / 24) - MIN (EVENT_TIME_UTC + 3 / 24)
FROM lenel.events@lenel_to_erp WHERE     empid = (SELECT id FROM emp@lenel_to_erp WHERE ssno = LPAD (TRUNC (LPAD (TRUNC (&emp_num), 5, '0')), 5,'0'))
AND TRUNC (EVENT_TIME_UTC) = TRUNC (SYSDATE);


SELECT TRXTYPE, TRXDATE, TRXTIME,
         (SELECT DESCRIPTION
            FROM TAS_TERMODMASTER@APPS_TO_NTAS
           WHERE TERMOD = TRXMACHINEID) AS PLACE
    FROM TAS_EMPBOOKINGS@APPS_TO_NTAS
   WHERE     EMPLOYEECODE = LPAD (TRUNC (LPAD (TRUNC (&emp_num), 5, '0')), 5,'0')
         AND TO_CHAR (TRXDATE, 'DD-MON-YY') = TO_CHAR (SYSDATE, 'DD-MON-YY')
ORDER BY 3;