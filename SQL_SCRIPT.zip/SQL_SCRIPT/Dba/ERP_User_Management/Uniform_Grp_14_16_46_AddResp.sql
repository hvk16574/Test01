DECLARE
   CURSOR c1
   IS
        SELECT   DISTINCT employee_number, full_name, papf.person_id,
                          email_address, date_of_birth, ROWNUM
          FROM   per_periods_of_service pps,
                 per_all_people_f papf,
                 per_all_assignments_f paf,
                 pay_people_groups ppg
         WHERE   pps.PERIOD_OF_SERVICE_ID = paf.PERIOD_OF_SERVICE_ID
                 AND papf.person_id = paf.person_id
                 AND SYSDATE BETWEEN Papf.effective_start_date
                                 AND  Papf.effective_end_date
                 AND SYSDATE BETWEEN Paf.effective_start_date
                                 AND  Paf.effective_end_date
                 AND current_employee_flag = 'Y' /* need to comment is require */
                 --AND hr_general.DECODE_GRADE (paf.grade_id) LIKE 'FD%'
                 AND pps.ACTUAL_TERMINATION_DATE IS NULL
                 AND paf.people_group_id = ppg.people_group_id
                 AND paf.primary_flag = 'Y'
                 AND ppg.segment6 IN 
                 ('QR_Uniform_Group_14', 'QR_Uniform_Group_16', 'QR_Uniform_Group_46')
                 AND employee_number IN (  SELECT   user_name FROM fnd_user)
      ORDER BY   ROWNUM;
   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER := NULL;
   x_start_date                   DATE := SYSDATE + 1;
   x_end_date                     DATE := NULL;
   x_last_logon_date              DATE := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE := NULL;
   x_password_accesses_left       NUMBER := NULL;
   x_password_lifespan_accesses   NUMBER := NULL;
   x_password_lifespan_days       NUMBER := NULL;
   x_employee_id                  NUMBER := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER := NULL;
   x_supplier_id                  NUMBER := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name := c1_rec.employee_number;
      x_unencrypted_password := TO_CHAR (c1_rec.date_of_birth, 'DDMMYYYY');
      apps.fnd_user_pkg.addresp (x_user_name,
                                 'PER',
                                 'QR_UNIFORM_REQUISITIONS',
                                 'STANDARD',
                                 NULL,
                                 x_start_date,
                                 NULL);
      DBMS_OUTPUT.put_line ('Updated Employee : ' || c1_rec.ROWNUM || ' : ' || x_user_name);
   END LOOP;
END;