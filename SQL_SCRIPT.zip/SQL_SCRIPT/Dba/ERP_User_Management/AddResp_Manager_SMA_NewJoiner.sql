DECLARE
   CURSOR c1
   IS
   SELECT   DISTINCT employee_number
    FROM   EMP_PHOTO
   WHERE   employee_number != '00001'
           AND employee_number IN (  SELECT   user_name FROM fnd_user)
ORDER BY   1;
   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER         := NULL;
   x_start_date                   DATE           := SYSDATE;
   x_end_date                     DATE           := NULL;
   x_last_logon_date              DATE           := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE           := NULL;
   x_password_accesses_left       NUMBER         := NULL;
   x_password_lifespan_accesses   NUMBER         := NULL;
   x_password_lifespan_days       NUMBER         := NULL;
   x_employee_id                  NUMBER         := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER         := NULL;
   x_supplier_id                  NUMBER         := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name := c1_rec.employee_number;
      apps.fnd_user_pkg.addresp (x_user_name,
                                 'PER',
                                 'QAG_SMA_NEW_JOINERS',
                                 'STANDARD',
                                 NULL,
                                 SYSDATE+1,
                                 NULL
                                );
      DBMS_OUTPUT.put_line (
      ' Added the QAG Manager Self Service - SMA Responsibility : '|| x_user_name);
--      DBMS_OUTPUT.put_line (x_user_name);
   END LOOP;
END;