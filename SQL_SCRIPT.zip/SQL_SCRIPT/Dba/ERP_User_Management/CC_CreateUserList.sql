SELECT DISTINCT employee_number, full_name, papf.person_id, email_address,
                date_of_birth
           FROM per_all_people_f papf,
                per_all_assignments_f paaf,
                per_grades pg
          WHERE papf.person_id = paaf.person_id
            AND organization_id = 574
            AND pg.grade_id = paaf.grade_id
            AND primary_flag = 'Y'
            AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                    AND paaf.effective_end_date
            AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                    AND papf.effective_end_date
            AND current_employee_flag = 'Y'
            AND employee_number NOT IN (SELECT user_name
                                          FROM fnd_user);
            
--            AND employee_number = '20455'