DECLARE
   CURSOR c1
   IS
      SELECT   papf.employee_number,
               papf.full_name,
               papf.person_id,
               papf.email_address,
               papf.date_of_birth,
               NVL (paaf.payroll_id, 0) payroll_id,
               paaf.organization_id,
               (CASE
                   WHEN hr_general.DECODE_GRADE (paaf.grade_id) LIKE 'FD%' THEN 'Deck Crew'
                   WHEN organization_id = 574 THEN 'Cabin Crew'
                   WHEN paaf.payroll_id = 61 THEN 'QR Employee'
                   WHEN payroll_id = 122 THEN 'DIA Employee'
                   WHEN payroll_id = 84 THEN 'QC Employee'
                   WHEN payroll_id = 142 THEN 'QD Employee'
                   WHEN payroll_id = 162 THEN 'QDFC Employee'
                   WHEN payroll_id = 202 THEN 'QAS Employee'
                   ELSE 'O/S OR NPA'
               END) Emp_Of,
               (CASE
                   WHEN hr_general.DECODE_GRADE (paaf.grade_id) LIKE 'FD%' THEN 'QAG_DECK_CREW_SSHR'
                   WHEN organization_id = 574 THEN 'QAG_CABIN_CREW_SSHR'
                   WHEN paaf.payroll_id = 61 THEN 'QR_EMPLOYEE_DIRECT_ACCESS'
                   WHEN payroll_id = 122 THEN 'DIA_EMPLOYEE_DIRECT_ACCESS'
                   WHEN payroll_id = 84 THEN 'QC_EMPLOYEE_DIRECT_ACCESS'
                   WHEN payroll_id = 142 THEN 'QD_EMPLOYEE_DIRECT_ACCESS'
                   WHEN payroll_id = 162 THEN 'QF_EMPLOYEE_DIRECT_ACCESS'
                   WHEN payroll_id = 202 THEN 'QS_EMPLOYEE_DIRECT_ACCESS'
                   ELSE 'O/S OR NPA'
               END) responsibility_key,
               HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id) org_name,
               papf.creation_date
        FROM   per_all_people_f papf, per_all_assignments_f paaf
       WHERE   TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                   AND  papf.effective_end_date
               AND papf.current_employee_flag = 'Y'
               AND papf.person_id = paaf.person_id
               AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                       AND  paaf.effective_end_date
               AND paaf.primary_flag = 'Y'
               AND papf.employee_number NOT IN
                        (SELECT   user_name FROM fnd_user)
               AND (paaf.payroll_id IN (61, 122, 84, 142, 162, 202)
                    OR organization_id = 574);
   --         AND papf.employee_number = :emp_num
   --         AND papf.creation_date >= TRUNC (SYSDATE - 59)
   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER := NULL;
   x_start_date                   DATE := SYSDATE;
   x_end_date                     DATE := NULL;
   x_last_logon_date              DATE := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE := NULL;
   x_password_accesses_left       NUMBER := NULL;
   x_password_lifespan_accesses   NUMBER := NULL;
   x_password_lifespan_days       NUMBER := NULL;
   x_employee_id                  NUMBER := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER := NULL;
   x_supplier_id                  NUMBER := NULL;
   x_responsibility_key           VARCHAR2 (30);
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name := c1_rec.employee_number;
      x_employee_id := c1_rec.person_id;
      x_email_address := c1_rec.email_address;
      x_description := c1_rec.full_name;
      x_unencrypted_password := TO_CHAR (c1_rec.date_of_birth, 'DDMMYYYY');
      x_responsibility_key := c1_rec.responsibility_key;
      apps.fnd_user_pkg.loaduser (x_user_name,
                                  0,
                                  x_unencrypted_password,
                                  x_session_number,
                                  x_start_date,
                                  x_end_date,
                                  x_last_logon_date,
                                  x_description,
                                  x_password_date,
                                  x_password_accesses_left,
                                  x_password_lifespan_accesses,
                                  x_password_lifespan_days,
                                  x_employee_id,
                                  x_email_address,
                                  x_fax,
                                  x_customer_id,
                                  x_supplier_id);
      apps.fnd_user_pkg.addresp (x_user_name,
                                 'PER',
                                 x_responsibility_key,
                                 'STANDARD',
                                 NULL,
                                 SYSDATE,
                                 NULL);
      DBMS_OUTPUT.put_line(   c1_rec.employee_number
                           || ' | '
                           || c1_rec.full_name
                           || ' | '
                           || c1_rec.emp_of
                           || ' | '
                           || c1_rec.responsibility_key
                           || ' | '
                           || c1_rec.org_name);
   END LOOP;
END;