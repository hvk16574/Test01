DECLARE
   CURSOR c1
   IS
        SELECT a.*
          FROM abc a, fnd_user
         where user_name =  lpad(trunc(lpad(trunc(en),5,'0')),5,'0')
      ORDER BY 1;

   CURSOR c2 (xxx VARCHAR2)
   IS
      SELECT responsibility_key rk, application_short_name asn
        FROM fnd_responsibility frr, fnd_application fa
       WHERE responsibility_id = (SELECT responsibility_id
                                    FROM fnd_responsibility_tl
                                   WHERE responsibility_name = XXX)
             AND fa.application_id = frr.application_id;

   x_user_name                    VARCHAR2 (200);
   x_owner                        VARCHAR2 (200);
   x_unencrypted_password         VARCHAR2 (200);
   x_session_number               NUMBER := NULL;
   x_start_date                   DATE := SYSDATE;
   x_end_date                     DATE := NULL;
   x_last_logon_date              DATE := NULL;
   x_description                  VARCHAR2 (200) := NULL;
   x_password_date                DATE := NULL;
   x_password_accesses_left       NUMBER := NULL;
   x_password_lifespan_accesses   NUMBER := NULL;
   x_password_lifespan_days       NUMBER := NULL;
   x_employee_id                  NUMBER := NULL;
   x_email_address                VARCHAR2 (200);
   x_fax                          VARCHAR2 (200) := NULL;
   x_customer_id                  NUMBER := NULL;
   x_supplier_id                  NUMBER := NULL;
   res_key                        VARCHAR2 (80) := NULL;
   x_asn                          VARCHAR2 (80) := NULL;
BEGIN
   FOR c1_rec IN c1
   LOOP
      x_user_name :=  lpad(trunc(lpad(trunc(c1_rec.en),5,'0')),5,'0');

      FOR c2_rec IN c2 (c1_rec.res)
      LOOP
         res_key := c2_rec.rk;
         x_asn := c2_rec.asn;
      apps.fnd_user_pkg.addresp (x_user_name,
                                 x_asn,
                                 res_key,
                                 'STANDARD',
                                 NULL,
                                 SYSDATE,
                                 NULL);
      DBMS_OUTPUT.put_line ('Responsibility ' || c1_rec.res || ' assigned to Staff# :' || x_user_name);
      END LOOP;
   END LOOP;
END;





