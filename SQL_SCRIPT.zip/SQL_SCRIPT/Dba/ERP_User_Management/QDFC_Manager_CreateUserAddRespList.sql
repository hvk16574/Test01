SELECT DISTINCT employee_number, full_name, a.person_id, a.email_address,
                date_of_birth
           FROM per_all_people_f a, per_all_assignments_f paaf, fnd_user u
          WHERE a.person_id = paaf.person_id
            AND payroll_id = 162
            AND primary_flag = 'Y'
            AND 1 <=
                   (SELECT COUNT (papf1.employee_number)
                      FROM per_all_people_f papf,
                           per_all_people_f papf1,
                           per_all_assignments_f paaf
                     WHERE paaf.supervisor_id = papf.person_id
                       AND papf1.person_id = paaf.person_id
                       AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                               AND papf.effective_end_date
                       AND papf.current_employee_flag = 'Y'
                       AND paaf.primary_flag = 'Y'
                       AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                               AND paaf.effective_end_date
                       AND papf.employee_number = a.employee_number
                       AND papf1.current_employee_flag = 'Y'
                       AND TRUNC (SYSDATE) BETWEEN papf1.effective_start_date
                                               AND papf1.effective_end_date)
            AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date
                                    AND paaf.effective_end_date
            AND TRUNC (SYSDATE) BETWEEN a.effective_start_date
                                    AND a.effective_end_date
            AND current_employee_flag = 'Y'
            AND u.user_name = a.employee_number
            AND u.user_id NOT IN (SELECT DISTINCT user_id
                                             FROM fnd_user_resp_groups_direct
                                            WHERE user_id NOT IN (
                                                                SELECT user_id
                                                                  FROM hello));


CREATE TABLE hello AS SELECT DISTINCT user_id
                              FROM fnd_user_resp_groups_direct
                             WHERE user_id NOT IN (
                                      SELECT DISTINCT user_id
                                                 FROM fnd_user_resp_groups_direct
                                                WHERE responsibility_application_id =
                                                                           800
                                                  AND responsibility_id =
                                                                         53076)

            AND employee_number NOT IN (SELECT user_name
                                          FROM fnd_user);