select ura.user_name, ura.role_name
from wf_local_user_roles ur, wf_user_role_assignments ura
where ur.user_name = ura.user_name
and ur.role_name = ura.role_name
and ura.relationship_id = -1
and ((ur.effective_start_date is null or ur.effective_start_date <>
ura.effective_start_date)
or (ur.effective_end_date is null or ur.effective_end_date <> ura.effective_end_date));  

-- If the above script returns any rows then:
-- Take a backup of the two tables :
-- WF_LOCAL_USER_ROLES and WF_USER_ROLE_ASSIGNMENTS
--create table WF_LOCAL_USER_ROLES_hk as select * from WF_LOCAL_USER_ROLES;

--create table WF_USER_ROLE_ASSIGNMENTS_hk as select * from WF_USER_ROLE_ASSIGNMENTS;

--Update script to correct the discrepancy :

UPDATE WF_USER_ROLE_ASSIGNMENTS set effective_end_date = to_date(null)
where rowid in (select ura.rowid 
                from wf_local_user_roles ur, wf_user_role_assignments ura 
                where ur.user_name = ura.user_name 
                  and ur.role_name = ura.role_name 
                  and ura.relationship_id = -1 
                  and ((ur.effective_start_date is null or ur.effective_start_date <>ura.effective_start_date) 
                  or (ur.effective_end_date is null or ur.effective_end_date <>ura.effective_end_date)));

-- Workflow Directory Services User/Role Validation
--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=--=*=-
select * from fnd_user where user_name = '17259'

create table hello_fu as select * from fnd_user where user_name = '17259';

delete from fnd_users where username = '17259';

insert into fnd_user select * from hello_fu;

commit;

fnd_user 
wf_user_role_assignments
wf_local_user_roles

wf_all_user_roles

FND_USER_RESP_GROUPS_DIRECT
wf_notifications

WF_USER_ROLES


select b.RESPONSIBILITY_NAME,a.START_DATE,a.END_DATE
from
FND_USER_RESP_GROUPS_ALL a,
FND_RESPONSIBILITY_TL b,
fnd_user c
where
a.user_id=c.user_id and
a.responsibility_id=b.responsibility_id
and c.USER_NAME=:emp_num

CREATE TABLE wf_user_role_assignments_hk AS SELECT   * FROM wf_user_role_assignments;

wf_user_role_assignments wura, wf_all_user_roles, wf_local_user_roles

UPDATE   wf_local_user_roles
   SET   user_end_date = NULL
 WHERE   user_name = 'SYSADMIN' AND user_end_date >= '25-AUG-2006';

UPDATE   wf_local_user_roles
   SET   effective_end_date = TO_DATE ('25-AUG-2020')
 WHERE   user_name = 'SYSADMIN' AND effective_end_date >= '25-AUG-2006';

  
  SELECT   user_name, user_orig_system, user_end_date, role_end_date, effective_end_date,
           last_updated_by, last_update_date
    FROM   wf_local_user_roles
   WHERE   role_name IN (SELECT   user_name FROM   fnd_user WHERE   end_date IS NULL)
           AND user_end_date IS NOT NULL
--           AND last_update_date = TO_DATE ('26/09/2009 11:03:56 AM', 'dd/mm/yyyy hh:mi:ss AM')
           AND user_name = :emp_num
ORDER BY   7 DESC;

SELECT   user_name, user_orig_system, user_end_date, role_end_date, effective_end_date,
           last_updated_by, last_update_date
    FROM   wf_user_role_assignments
   WHERE   role_name IN (SELECT   user_name FROM   fnd_user WHERE   end_date IS NULL)
           AND user_end_date IS NOT NULL
--           AND last_update_date = TO_DATE ('26/09/2009 11:03:56 AM', 'dd/mm/yyyy hh:mi:ss AM')
--           AND user_name = :emp_num
ORDER BY   7 DESC;


UPDATE   wf_local_user_roles
   SET   user_end_date = NULL, role_end_date = NULL, effective_end_date = TO_DATE ('01/01/9999', 'dd/mm/yyyy')
 WHERE   role_name IN (SELECT   user_name FROM   fnd_user WHERE   end_date IS NULL)
         AND user_end_date IS NOT NULL;

UPDATE   wf_user_role_assignments
   SET   user_end_date = NULL, role_end_date = NULL, effective_end_date = TO_DATE ('01/01/9999', 'dd/mm/yyyy')
 WHERE   role_name IN (SELECT   user_name FROM   fnd_user WHERE   end_date IS NULL)
         AND user_end_date IS NOT NULL;