SET SERVEROUTPUT ON SIZE 1000000
SET FEEDBACK OFF

DECLARE
  v_prefix      VARCHAR2(5)   := NULL;
  v_condition   VARCHAR2(30)  := NULL;

  CURSOR ctabhis IS
    SELECT table_name FROM dba_tables a
      WHERE table_name NOT LIKE '%$HIS' AND owner = 'SYSTEM' AND table_name = 'AUDIT_IP'
      AND EXISTS  (SELECT 'x' FROM dba_tables b WHERE b.table_name = SUBSTR(a.table_name,1,26) || '$HIS');

  CURSOR ccolhis(p_audittbl USER_TABLES.TABLE_NAME%TYPE) IS
    SELECT column_name FROM dba_tab_columns
      WHERE table_name  = p_audittbl AND column_name NOT IN ('HIS_ACTION','HIS_TIMESTAMP','HIS_USER') ORDER BY column_id;
BEGIN
  FOR ctabhis_row IN ctabhis LOOP
    DBMS_OUTPUT.PUT_LINE('CREATE OR REPLACE TRIGGER '|| SUBSTR(ctabhis_row.table_name,1,23)||'$HISTRG '||CHR(10)||
     ' AFTER INSERT OR DELETE OR UPDATE '|| 'ON '||ctabhis_row.table_name|| ' FOR EACH ROW ');
    v_prefix       := ':new';
    v_condition    := 'IF INSERTING OR UPDATING THEN';
    DBMS_OUTPUT.PUT_LINE('DECLARE '||CHR(10)|| 'v_operation VARCHAR2(10) := NULL;');
    DBMS_OUTPUT.PUT_LINE('BEGIN ');
    IF v_prefix = ':new' THEN 
       DBMS_OUTPUT.PUT_LINE(
        '    IF INSERTING THEN '||CHR(10)||
        '       v_operation := ''INS''; '||CHR(10)||
        '    ELSIF UPDATING THEN '||CHR(10)||
        '       v_operation := ''UPD''; '||CHR(10)||
        '    ELSE '||CHR(10)||
        '       v_operation := ''DEL''; '||CHR(10)||
        '    END IF; '||CHR(13));
    END IF;
    LOOP
      DBMS_OUTPUT.PUT_LINE(v_condition||CHR(10));
      DBMS_OUTPUT.PUT_LINE('   INSERT INTO '|| SUBSTR(ctabhis_row.table_name,1,26) || '$HIS (');
      FOR ccolhis_row IN ccolhis(ctabhis_row.table_name) LOOP
      DBMS_OUTPUT.PUT_LINE(ccolhis_row.column_name|| ',');
      END LOOP;
      DBMS_OUTPUT.PUT_LINE('HIS_action,HIS_timestamp,HIS_user) '||'VALUES (');
      FOR ccolhis_row IN ccolhis( ctabhis_row.table_name) LOOP
        DBMS_OUTPUT.PUT_LINE(v_prefix||'.'||ccolhis_row.column_name|| ',');
      END LOOP;
      DBMS_OUTPUT.PUT_LINE('v_operation,SYSDATE,USER);'||CHR(10));
       EXIT WHEN v_prefix = ':old';
         v_prefix := ':old';
         v_condition := 'ELSE ';
     END LOOP;
     DBMS_OUTPUT.PUT_LINE('   END IF;'||CHR(10)||'END;'||CHR(10)||'/'||CHR(10));
   END LOOP; 

END;
/