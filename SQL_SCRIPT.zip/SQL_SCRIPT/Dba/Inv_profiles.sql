  SELECT   a.profile_option_id ID,
           a.level_value Level_Code,
           e.profile_option_name Profile,
           f.user_profile_option_name profile_name,
           DECODE (a.level_id,
                   10001,
                   'Site',
                   10002,
                   'Appl',
                   10003,
                   'Resp',
                   10004,
                   'User')
              L,
           DECODE (a.level_id,
                   10001,
                   'Site',
                   10002,
                   c.application_short_name,
                   10003,
                   b.responsibility_name,
                   10004,
                   d.user_name)
              LValue,
           NVL (a.profile_option_value, 'Is Null') VALUE
    FROM   fnd_profile_option_values a,
           fnd_responsibility_tl b,
           fnd_application c,
           fnd_user d,
           fnd_profile_options e,
           fnd_profile_options_tl f
   WHERE   e.profile_option_id = a.profile_option_id
           AND UPPER (f.user_profile_option_name) IN
                    (SELECT   UPPER (user_Profile_Option_name)
                       FROM   fnd_profile_options_vl
                      WHERE   application_id IN
                                    (SELECT   application_id
                                       FROM   fnd_application
                                      WHERE   UPPER (product_code) =
                                                 UPPER ('INV')))
           AND a.level_value = b.responsibility_id(+)
           AND a.level_value = c.application_id(+)
           AND a.level_value = d.user_id(+)
           AND e.profile_option_name = f.profile_option_name
ORDER BY   e.profile_option_name, a.level_id ASC;