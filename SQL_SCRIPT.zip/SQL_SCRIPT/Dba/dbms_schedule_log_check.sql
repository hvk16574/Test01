SELECT   DSJ.JOB_NAME, DSJL.STATUS, DSJL.LOG_DATE
  FROM   DBA_SCHEDULER_JOBS dsj, DBA_SCHEDULER_JOB_LOG dsjl
 WHERE       DSJ.OWNER = 'APPS'
         AND DSJ.JOB_NAME = DSJL.JOB_NAME
         AND TRUNC (DSJL.LOG_DATE) >= TRUNC (SYSDATE)
         AND DSJL.STATUS != 'SUCCEEDED';
         
         
DECLARE
   a   VARCHAR2 (1000);
BEGIN
   DBMS_SCHEDULER.get_attribute ('LENEL_MASTER_UPDATE', 'max_run_duration', a);
   DBMS_OUTPUT.put_line (a);
END;


BEGIN
   DBMS_SCHEDULER.set_attribute ('LENEL_MASTER_UPDATE', 'max_run_duration', INTERVAL '10' MINUTE);
END;         