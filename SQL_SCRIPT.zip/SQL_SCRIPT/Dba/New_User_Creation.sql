SELECT   papf.employee_number,
         papf.full_name,
         papf.person_id,
         hr_general.DECODE_GRADE (paaf.grade_id),
         papf.email_address,
         papf.date_of_birth,
         NVL (paaf.payroll_id, 0) payroll_id,
         paaf.organization_id,
         (CASE
             WHEN hr_general.DECODE_GRADE (paaf.grade_id) LIKE 'FD%' THEN 'Deck Crew'
             WHEN organization_id = 574 THEN 'Cabin Crew'
             WHEN paaf.payroll_id = 61 THEN 'QR Employee'
             WHEN payroll_id = 122 THEN 'DIA Employee'
             WHEN payroll_id = 84 THEN 'QC Employee'
             WHEN payroll_id = 142 THEN 'QD Employee'
             WHEN payroll_id = 162 THEN 'QDFC Employee'
             WHEN payroll_id = 202 THEN 'QAS Employee'
             ELSE 'O/S OR NPA'
          END)
            Emp_Of,
         (CASE
             WHEN hr_general.DECODE_GRADE (paaf.grade_id) LIKE 'FD%' THEN 'QAG_DECK_CREW_SSHR'
             WHEN organization_id = 574 THEN 'QAG_CABIN_CREW_SSHR'
             WHEN paaf.payroll_id = 61 THEN 'QR_EMPLOYEE_DIRECT_ACCESS'
             WHEN payroll_id = 122 THEN 'DIA_EMPLOYEE_DIRECT_ACCESS'
             WHEN payroll_id = 84 THEN 'QC_EMPLOYEE_DIRECT_ACCESS'
             WHEN payroll_id = 142 THEN 'QD_EMPLOYEE_DIRECT_ACCESS'
             WHEN payroll_id = 162 THEN 'QF_EMPLOYEE_DIRECT_ACCESS'
             WHEN payroll_id = 202 THEN 'QS_EMPLOYEE_DIRECT_ACCESS'
             ELSE 'O/S OR NPA'
          END)
            responsibility_key,
         HR_GENERAL.DECODE_ORGANIZATION (paaf.organization_id) org_name,
         papf.creation_date
  FROM   per_all_people_f papf, per_all_assignments_f paaf
 WHERE       TRUNC (SYSDATE) BETWEEN papf.effective_start_date AND papf.effective_end_date
         AND papf.current_employee_flag = 'Y'
         AND papf.person_id = paaf.person_id
         AND TRUNC (SYSDATE) BETWEEN paaf.effective_start_date AND paaf.effective_end_date
         AND paaf.primary_flag = 'Y'
         AND papf.employee_number IN
                  (SELECT   user_name
                     FROM   fnd_user
                    WHERE   user_id NOT IN
                                  (SELECT   user_id
                                     FROM   fnd_user_resp_groups_direct
                                    WHERE   RESPONSIBILITY_ID IN
                                                  (SELECT   RESPONSIBILITY_ID
                                                     FROM   fnd_responsibility
                                                    WHERE   RESPONSIBILITY_KEY IN
                                                                  ('QAG_DECK_CREW_SSHR',
                                                                   'QAG_CABIN_CREW_SSHR',
                                                                   'QR_EMPLOYEE_DIRECT_ACCESS',
                                                                   'DIA_EMPLOYEE_DIRECT_ACCESS',
                                                                   'QC_EMPLOYEE_DIRECT_ACCESS',
                                                                   'QD_EMPLOYEE_DIRECT_ACCESS',
                                                                   'QF_EMPLOYEE_DIRECT_ACCESS',
                                                                   'QS_EMPLOYEE_DIRECT_ACCESS',
                                                                   'QR_MANAGER_DIRECT_ACCESS',
                                                                   'DIA_MANAGER_DIRECT_ACCESS',
                                                                   'QC_MANAGER_DIRECT_ACCESS',
                                                                   'QD_MANAGER_DIRECT_ACCESS',
                                                                   'QF_MANAGER_DIRECT_ACCESS',
                                                                   'QS_MANAGER_DIRECT_ACCESS'))
                                            AND RESPONSIBILITY_application_ID = 800))
         AND (paaf.payroll_id IN (61, 122, 84, 142, 162, 202) OR organization_id = 574);
                    
   --         AND papf.employee_number = :emp_num
   --         AND papf.creation_date >= TRUNC (SYSDATE - 59)