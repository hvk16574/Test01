DECLARE
    v_user_name      VARCHAR2 (30);
    v_new_password   VARCHAR2 (30) := 'Test2018cp';
    v_status         BOOLEAN;
    CURSOR c1    IS        SELECT * FROM a;
BEGIN
    FOR c1_rec IN c1
    LOOP
        DBMS_OUTPUT.ENABLE (1000000);
        v_user_name := c1_rec.employee_number;
        v_status :=
            fnd_user_pkg.changepassword (username      => v_user_name, newpassword   => v_new_password);
        IF v_status = TRUE
        THEN
            DBMS_OUTPUT.put_line ( 'The password reset successfully for the User:' || v_user_name);
            COMMIT;
        ELSE
            DBMS_OUTPUT.put_line ( v_user_name || ' - ' || 'Unable to reset password due to' || SQLCODE || ' ' || SUBSTR (SQLERRM, 1, 100));
            ROLLBACK;
        END IF;
    END LOOP;
END;