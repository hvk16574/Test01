SELECT COUNT (b.line_num) "Items Processed"
  FROM po_requisition_headers_all a, po_requisition_lines_all b
 WHERE a.requisition_header_id = b.requisition_header_id
   AND b.creation_date BETWEEN TO_DATE ('01/10/2008', 'DD/MM/YYYY')
                           AND TO_DATE ('31/10/2008', 'DD/MM/YYYY');

SELECT COUNT (b.line_num) "Items Processed"
  FROM po_headers_all a, po_lines_all b
 WHERE a.po_header_id = b.po_header_id
   AND b.creation_date BETWEEN TO_DATE ('01/10/2008', 'DD/MM/YYYY')
                           AND TO_DATE ('31/10/2008', 'DD/MM/YYYY');

SELECT COUNT (1)
  FROM mtl_material_transactions
 WHERE creation_date BETWEEN TO_DATE ('01/10/2008', 'DD/MM/YYYY')
                         AND TO_DATE ('31/10/2008', 'DD/MM/YYYY');

SELECT COUNT (1)
  FROM ap_invoices_all
 WHERE creation_date BETWEEN TO_DATE ('01/09/2008', 'DD/MM/YYYY')
                         AND TO_DATE ('30/09/2008', 'DD/MM/YYYY');

SELECT COUNT (1)
  FROM ap_invoice_payments_all
 WHERE creation_date BETWEEN TO_DATE ('01/10/2008', 'DD/MM/YYYY')
                         AND TO_DATE ('30/10/2008', 'DD/MM/YYYY');

SELECT COUNT (1)
  FROM gl_je_headers
 WHERE creation_date BETWEEN TO_DATE ('01/11/2008', 'DD/MM/YYYY')
                         AND TO_DATE ('30/11/2008', 'DD/MM/YYYY');

SELECT COUNT (1)
  FROM fa_transaction_headers
 WHERE transaction_date_entered BETWEEN TO_DATE ('01/10/2008', 'DD/MM/YYYY')
                                    AND TO_DATE ('31/10/2008', 'DD/MM/YYYY');