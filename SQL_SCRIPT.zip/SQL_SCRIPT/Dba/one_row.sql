SELECT SUBSTR (SYS_CONNECT_BY_PATH (node_name , ', '), 2) nodes
      FROM (SELECT node_name , ROW_NUMBER () OVER (ORDER BY node_name ) rn,
                   COUNT (*) OVER () cnt
              FROM fnd_nodes)
     WHERE rn = cnt
START WITH rn = 1
CONNECT BY rn = PRIOR rn + 1;