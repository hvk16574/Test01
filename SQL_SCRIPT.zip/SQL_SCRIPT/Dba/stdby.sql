select DEST_ID,dest_name,status,type,srl,recovery_mode from v$archive_dest_status where dest_id=1;

select sequence#,ARCHIVED,APPLIED from v$archived_log order by sequence# desc;


select * from v$standby_log;



select sequence#, first_time, next_time, COMPLETION_TIME 
from v$archived_log 
order by 4 desc ;



select * from v$logfile;

select DEST_ID,dest_name,status,type,srl,recovery_mode from v$archive_dest_status where dest_id=1;

select sequence#,ARCHIVED,APPLIED from v$archived_log order by sequence# desc;


select GROUP#,THREAD#,SEQUENCE#,STATUS,LAST_CHANGE#,LAST_TIME from v$standby_log;


select START_TIME,TYPE, ITEM,UNITS,SOFAR,TIMESTAMP
from v$recovery_progress where ITEM='Last Applied Redo';


select * from v$recovery_progress

select * from v$standby_log;