SELECT   s.inst_id,
         s.sid,
         p.spid,
         s.osuser,
         s.username,
         s.program
  FROM   gv$process p, gv$session s
 WHERE   p.inst_id = s.inst_id 
 AND p.addr = s.paddr 
 AND p.spid = 29616