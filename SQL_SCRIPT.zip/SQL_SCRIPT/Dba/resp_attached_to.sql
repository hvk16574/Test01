SELECT
  fu.user_name,
  fu.description,
  frt.responsibility_name,

  TO_CHAR(furg.start_date,'DD-MON-YYYY') start_date,
  furg.end_date
FROM fnd_user fu ,
  fnd_user_resp_groups_direct furg ,
  fnd_responsibility_vl frt
WHERE fu.user_id                 = furg.user_id
AND frt.responsibility_id        = furg.responsibility_id
AND frt.application_id           = furg.responsibility_application_id
--AND NVL(furg.end_date,sysdate+1) > sysdate  -- this condition will display active responsibilities only
AND NVL(frt.end_date,sysdate +1) > sysdate
AND NVL(fu.end_date,sysdate  +1) > sysdate
AND frt.responsibility_name      = :responsibility_name
order by user_name
