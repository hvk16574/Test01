select *from gdba_dml_locks 

select * from gv$session where sid = 3865

alter session set "_optimizer_cartesian_enabled"=false; 

select /*+RULE */ * from gv$access where object = ''