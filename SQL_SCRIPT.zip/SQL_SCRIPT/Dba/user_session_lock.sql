select sessions_current "Users logged on"
  from v$license;

select count(*) "Users running"
  from v$session_wait
 where wait_time!=0;

select substr(w.sid,1,5) "Sid",
          substr(s.username,1,15) "User",
          substr(s.event,1,80) "Event",
          s.seconds_in_wait "Wait [s]"
from v$session_wait w, v$session s
where s.sid = w.sid
   and s.state = 'WAITING'
   and s.event not like 'SQL*Net%'
   and s.event != 'client message'
   and s.event not like '%mon timer'
   and s.event != 'rdbms ipc message'
   and s.event != 'Null Event';
   
--

select * --count(*) "Users waiting for locks"
  from v$session
 where lockwait is not null;
