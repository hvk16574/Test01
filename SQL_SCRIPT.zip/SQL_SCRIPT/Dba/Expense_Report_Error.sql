SELECT   papf.FULL_NAME, aerh.*
    FROM ap_expense_report_headers_all aerh, per_all_people_f papf
    where papf.PERSON_ID = aerh.EMPLOYEE_ID and 
    aerh.invoice_num in (
SELECT   invoice_num
    FROM ap_expense_report_headers_all
   WHERE reject_code = 'DUPLICATE INVOICE NUMBER'
GROUP BY invoice_num, org_id
  HAVING COUNT (1) > 1)


SELECT   invoice_num, org_id, COUNT (1)
    FROM ap_expense_report_headers_all
   WHERE reject_code = 'DUPLICATE INVOICE NUMBER'
GROUP BY invoice_num, org_id
  HAVING COUNT (1) > 1;

