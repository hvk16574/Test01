SELECT *
  FROM   fnd_profile_option_values AS OF TIMESTAMP to_timestamp('10-04-2016 20:00:21','dd-mm-yyyy hh24:mi:ss');
  
  
  


create table fnd_profile_option_values_10 as select * from fnd_profile_option_values;   



FLASHBACK TABLE fnd_profile_option_values TO TIMESTAMP to_timestamp('10-04-2016 19:30:00','dd-mm-yyyy hh24:mi:ss');



select REFERENCED_NAME from dba_dependencies where type ='MATERIALIZED VIEW' and name = 'FND_PROFILE_OPTION_VALUES';




select dbms_metadata.get_ddl('MATERIALIZED_VIEW','FND_PROFILE_OPTION_VALUES') from dual;



select * from fnd_profile_option_values --_10
minus 
SELECT *  FROM   fnd_profile_option_values AS OF TIMESTAMP to_timestamp('10-04-2016 20:00:21','dd-mm-yyyy hh24:mi:ss');