<RULESET title="Code Efficiency" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.6743156134</CREATED>
<MODIFIED>38447.6745396875</MODIFIED>
<COMMENTS>This rule set helps identify constructs that generally have a high impact on code size and run-time speed. Software efficiency problems can often be isolated to constructs that either generate large amounts of code or execute more slowly.</COMMENTS>
<RULESET_TOTAL>15</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <TYPE Type="2" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>

