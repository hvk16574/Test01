<RULESET title="Control Structures" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38069.5600010185</CREATED>
<MODIFIED>38069.5702000694</MODIFIED>
<COMMENTS>This rule set helps isolate problems with conditional control processing such as loops, IF statements, and GOTO statements.</COMMENTS>
<RULESET_TOTAL>21</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <CATEGORY cat="40" />
	<CATEGORY cat="42" />
	<CATEGORY cat="48" />	
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>

