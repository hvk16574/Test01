#!/bin/sh
# processmem - display memory claimed by a process
#
if [ $# -lt 1 -o \( $# -gt 1 -a $# -lt 4 \) ]
then
  echo "Usage:"
  echo "processmem \"process\""
  echo "Example:"
  echo "processmem rpc"
  exit 1
fi
echo " "

PROCESS=$1

mps=0
#for sz in `ps -elf | grep $PROCESS | grep -v grep | awk '{print $10}'`
for sz in `UNIX95= ps -e -o vsz=Kbytes -o ruser -o pid,args=Command-Line | sort -rnk1 | grep -v Kbytes | grep $PROCESS | awk '{print $1}'`
do
mps=`expr $mps + $sz`
done
#echo `expr $mps \* 4096`
echo "\nMemory claimed by $PROCESS: $mps Kbytes.\n"
