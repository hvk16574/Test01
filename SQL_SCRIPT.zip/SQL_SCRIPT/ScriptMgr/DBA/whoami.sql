set echo off
set heading off
set feedback off

prompt
prompt User Connected As
prompt

select '*** User = '||user||' ***' from dual;